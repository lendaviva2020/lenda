# #osucessodetodamulher - Admin Marketplace & Gift Card

Este projeto é modular, escalável e pronto para evoluir.  
Aqui estão exemplos de cada módulo (Cartão-presente, Marketplace, Gráficos de vendas), rotas de admin, proteção de acesso e como integrar cada parte.

---

## 📂 Estrutura Recomendada

```
src/
  app/
    admin/
      index.tsx         // Página principal do admin (dashboard)
      login.tsx         // Login do admin
      giftcards/
      vendors/
      sales/
      ...
  components/
    admin/
      GiftCardForm.tsx
      GiftCardTable.tsx
      VendorApprovalPanel.tsx
      ProductsByVendor.tsx
      SalesChart.tsx
      ...
    client/
      RedeemGiftCard.tsx
    ui/
      ProtectedRoute.tsx
      ...
  hooks/
    useGiftCards.ts
    useVendors.ts
    useSales.ts
    useAuth.ts
  types/
    giftcard.ts
    vendor.ts
    sale.ts
  ...
```

---

## 🛡️ Proteção de Acesso (Exemplo)

```typescript name=src/components/ui/ProtectedRoute.tsx
import { useAuth } from "@/hooks/useAuth";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push("/admin/login");
    }
  }, [user, loading, router]);

  if (loading || !user) return <div>Carregando...</div>;
  return <>{children}</>;
}
```

Use em qualquer página admin assim:

```typescript
import ProtectedRoute from "@/components/ui/ProtectedRoute";
export default function AdminDashboard() {
  return (
    <ProtectedRoute>
      {/* seu conteúdo do admin */}
    </ProtectedRoute>
  );
}
```

---

## 🏠 Página Principal do Admin

```typescript name=src/app/admin/index.tsx
"use client";
import ProtectedRoute from "@/components/ui/ProtectedRoute";
import Link from "next/link";

export default function AdminDashboard() {
  return (
    <ProtectedRoute>
      <div>
        <h1>Admin - #osucessodetodamulher</h1>
        <ul>
          <li><Link href="/admin/giftcards">Cartões-presente</Link></li>
          <li><Link href="/admin/vendors">Lojistas (Marketplace)</Link></li>
          <li><Link href="/admin/sales">Gráficos de Vendas</Link></li>
        </ul>
      </div>
    </ProtectedRoute>
  );
}
```

---

## 🪪 Exemplo de Rota de Login do Admin

```typescript name=src/app/admin/login.tsx
"use client";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useRouter } from "next/navigation";

export default function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login, user } = useAuth();
  const router = useRouter();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    await login(email, password);
    router.push("/admin");
  }

  if (user) {
    router.push("/admin");
    return null;
  }

  return (
    <form onSubmit={handleLogin}>
      <h2>Login Admin</h2>
      <input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required />
      <input type="password" placeholder="Senha" value={password} onChange={e=>setPassword(e.target.value)} required />
      <button type="submit">Entrar</button>
    </form>
  );
}
```

---

## 📊 Gráficos de Vendas (Exemplo de uso)

```typescript name=src/app/admin/sales/page.tsx
"use client";
import ProtectedRoute from "@/components/ui/ProtectedRoute";
import SalesChart from "@/components/admin/SalesChart";

export default function SalesPage() {
  return (
    <ProtectedRoute>
      <div>
        <h2>Dashboard de Vendas</h2>
        <SalesChart />
      </div>
    </ProtectedRoute>
  );
}
```

---

## 🛍️ Cartão-Presente (CRUD Admin)

```typescript name=src/app/admin/giftcards/page.tsx
"use client";
import { useGiftCards } from "@/hooks/useGiftCards";
import GiftCardForm from "@/components/admin/GiftCardForm";
import { useState } from "react";
import ProtectedRoute from "@/components/ui/ProtectedRoute";

export default function GiftCardsAdminPage() {
  const { items: giftcards, add, update, remove } = useGiftCards();
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);

  function handleEdit(gc) {
    setEditing(gc);
    setShowForm(true);
  }
  function handleDelete(id) {
    remove(id);
  }
  function handleSave(gc) {
    if (editing) {
      update(editing.id, gc);
    } else {
      add(gc);
    }
    setEditing(null);
    setShowForm(false);
  }

  return (
    <ProtectedRoute>
      <h2>Cartões-presente</h2>
      <button onClick={() => { setShowForm(true); setEditing(null); }}>+ Novo Cartão</button>
      <table>
        <thead>
          <tr><th>Código</th><th>Valor</th><th>Status</th><th>Ações</th></tr>
        </thead>
        <tbody>
          {giftcards.map(gc => (
            <tr key={gc.id}>
              <td>{gc.code}</td>
              <td>R${gc.value}</td>
              <td>{gc.used ? "Usado" : "Disponível"}</td>
              <td>
                <button onClick={() => handleEdit(gc)}>Editar</button>
                <button onClick={() => handleDelete(gc.id)}>Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {showForm && (
        <GiftCardForm initial={editing || undefined} onSave={handleSave} onCancel={() => setShowForm(false)} />
      )}
    </ProtectedRoute>
  );
}
```

---

## 🏬 Marketplace - Aprovação de Lojistas

```typescript name=src/app/admin/vendors/page.tsx
"use client";
import VendorApprovalPanel from "@/components/admin/VendorApprovalPanel";
import ProtectedRoute from "@/components/ui/ProtectedRoute";

export default function VendorsAdminPage() {
  return (
    <ProtectedRoute>
      <h2>Lojistas (Marketplace)</h2>
      <VendorApprovalPanel />
    </ProtectedRoute>
  );
}
```

---

## 📣 Como evoluir

- Implemente cada módulo como mostrado acima, um por vez.
- Ajuste os tipos/hooks/components conforme sua regra de negócio.
- Use `ProtectedRoute` para proteger qualquer rota admin.
- Os hooks (`useGiftCards`, `useVendors`, `useSales`) são exemplos de CRUD genérico.
- Use Chart.js ou Recharts para os gráficos.
- Expanda para outros módulos conforme seu roadmap.

---

## 📝 Dúvidas?

Se quiser adicionar módulos, rotas, exemplos de componentes ou integrações específicas, peça indicando o nome do recurso!

---