# Envio de Notificações Push com Filtros (Frontend/Admin Web)

## Como funciona

- Acesse `/admin/push` no painel web.
- Escolha o tipo de disparo: por **categoria** (todos admins daquela área) ou por **usuário** (um admin específico).
- Preencha o formulário com título, mensagem e, se quiser, um objeto de dados extra em JSON (ex: {"screen":"Sales"}).
- Clique em "Enviar Notificação". O backend encaminha a notificação filtrada via Firebase/FCM.

## Backend

- Endpoints `/push/category` e `/push/user` recebem as requisições, buscam os tokens filtrados e disparam o push.
- Veja exemplos em `backend/routes/push.js` e `backend/models/admin.js`.

## Frontend

- Componente reutilizável `PushNotificationForm.tsx` para formulário de disparo.
- Pronto para ser usado em qualquer painel React (Next.js, CRA, etc).

---

Se quiser expandir para outros filtros (ex: loja, grupo de usuários), basta adaptar as funções de busca de tokens.