# Dashboard Financeiro, Gráficos e Notificações Push (App Admin)

## Recursos inclusos
- Dashboard financeiro interativo com gráficos de linha e barra (use `react-native-chart-kit`)
- Tela de notificações administrativas (push e internas)
- Integração com push notifications via Expo (registro e recebimento)
- Navegação tab para acesso rápido a todos os módulos administrativos

## Como expandir
- Use endpoints REST/GraphQL idênticos ao admin web
- Inclua filtros de período, exportação e mais tipos de gráficos conforme necessidade
- Implemente notificações push para aprovar vendas, alertar sobre fraudes, etc.
- Acesse relatórios em tempo real pelo app

## Dica
Para gráficos ainda mais avançados, utilize também a lib [victory-native](https://formidable.com/open-source/victory/docs/native/) ou [react-native-svg-charts](https://github.com/JesperLekland/react-native-svg-charts).

---