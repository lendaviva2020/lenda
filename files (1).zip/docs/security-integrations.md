# Integrações de Segurança (Cloudflare, WAF, Antifraude)

## Cloudflare & Turnstile
- Ative Cloudflare para seu domínio e use regras de WAF, Rate Limiting e Bot Management.
- Implemente o componente `CloudflareTurnstile` em formulários sensíveis (login, registro, checkout).
- Valide o token do Turnstile no backend usando `verifyCloudflareTurnstile`.

## Web Application Firewall (WAF)
- Configure regras personalizadas no painel Cloudflare (ex: bloquear países, User-Agents suspeitos, URLs específicas).
- Use `blockUserAgent` no backend para reforço extra.

## Antifraude (ex: ClearSale, Konduto)
- Envie o pedido para análise antifraude antes de aprovar o pagamento.
- Implemente uma rotina assíncrona para reprocessar pedidos em "manual review".

## Dicas Adicionais
- Armazene IP de cada requisição e monitore padrões suspeitos.
- Audite e alerte sobre tentativas de bypass no painel admin.
- Atualize dependências e mantenha o ambiente sempre revisado.

---