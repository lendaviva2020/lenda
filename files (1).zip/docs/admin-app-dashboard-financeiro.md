# Dashboard Financeiro, Gráficos Interativos e Notificações Push

## Funcionalidades prontas

- **Dashboard financeiro** com saldo, planejamento, receitas, gastos, resumo semanal e histórico de transações, inspirado no GuiaBolso (imagem 1).
- **Gráficos interativos** de pizza (categorias) e linha/barra (tendência de receita, vendas por categoria).
- **Notificações push** para o administrador — use `usePushNotifications` para registrar o dispositivo e `AdminNotifications` para exibir.
- **Navegação tab** para fácil acesso a todos os módulos administrativos.

## Como expandir

-
, só pedir!