// Acrescente a chamada do hook de push notifications após o login do admin
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import LoginScreen from "./screens/LoginScreen";
import AdminTabs from "./screens/AdminTabs";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import { usePushNotifications } from "./hooks/usePushNotifications";

const Stack = createNativeStackNavigator();

function MainApp() {
  const { user } = useAuth();
  usePushNotifications(user?.id || "");
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        <Stack.Screen name="AdminTabs" component={AdminTabs} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}