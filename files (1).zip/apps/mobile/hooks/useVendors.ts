import { useEffect, useState } from "react";
import { Vendor } from "../../src/types/vendor";
// Troque abaixo para seu backend/API real
export function useVendors() {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  useEffect(() => {
    fetch("https://api.seusite.com/vendors")
      .then(r => r.json())
      .then(setVendors);
  }, []);
  async function approveVendor(id: string) {
    await fetch(`https://api.seusite.com/vendors/${id}/approve`, { method: "POST" });
    setVendors(vs => vs.map(v => v.id === id ? { ...v, approved: true } : v));
  }
  return { vendors, approveVendor };
}