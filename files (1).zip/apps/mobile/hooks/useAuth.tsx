import React, { createContext, useContext, useState } from "react";
import * as SecureStore from "expo-secure-store";

type AuthContextType = {
  user: null | { id: string; email: string; isAdmin: boolean };
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  login: async () => {},
  logout: () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthContextType["user"]>(null);
  const [token, setToken] = useState<string | null>(null);

  async function login(email: string, password: string) {
    const res = await fetch("https://api.seusite.com/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (res.ok) {
      const data = await res.json();
      setUser(data.admin);
      setToken(data.token);
      await SecureStore.setItemAsync("token", data.token);
    } else {
      throw new Error("Login inválido");
    }
  }
  function logout() {
    setUser(null);
    setToken(null);
    SecureStore.deleteItemAsync("token");
  }

  return (
    <AuthContext.Provider value={{ user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}