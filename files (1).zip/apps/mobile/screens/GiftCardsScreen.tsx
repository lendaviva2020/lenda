import React, { useEffect, useState } from "react";
import { View, Text, FlatList, Button, TextInput, Alert } from "react-native";
export default function GiftCardsScreen() {
  const [cards, setCards] = useState<any[]>([]);
  const [value, setValue] = useState("");
  useEffect(() => {
    fetch("https://api.seusite.com/giftcards")
      .then(r => r.json())
      .then(setCards);
  }, []);
  async function addCard() {
    try {
      const res = await fetch("https://api.seusite.com/giftcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ value: parseFloat(value) }),
      });
      if (res.ok) {
        const newCard = await res.json();
        setCards(cs => [newCard, ...cs]);
        setValue("");
      } else throw new Error("Erro ao criar cartão");
    } catch (e) {
      Alert.alert("Erro", (e as Error).message);
    }
  }
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: "bold", marginBottom: 8 }}>Cartões-Presente</Text>
      <View style={{ flexDirection: "row", gap: 8, marginBottom: 12 }}>
        <TextInput placeholder="Valor" value={value} onChangeText={setValue} keyboardType="decimal-pad" style={{ borderWidth: 1, borderRadius: 8, padding: 8, width: 90 }} />
        <Button title="Criar" onPress={addCard} />
      </View>
      <FlatList
        data={cards}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={{ padding: 10, borderBottomWidth: 1, borderColor: "#eee" }}>
            <Text>Código: {item.code}</Text>
            <Text>Valor: R$ {item.value}</Text>
            <Text>Status: {item.used ? "Usado" : "Disponível"}</Text>
          </View>
        )}
      />
    </View>
  );
}