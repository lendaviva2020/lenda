import React, { useEffect, useState } from "react";
import { View, Text, FlatList } from "react-native";

export default function SalesScreen() {
  const [sales, setSales] = useState<any[]>([]);
  useEffect(() => {
    fetch("https://api.seusite.com/sales")
      .then(r => r.json())
      .then(setSales);
  }, []);
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: "bold", marginBottom: 8 }}>Vendas Recentes</Text>
      <FlatList
        data={sales}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={{ padding: 10, borderBottomWidth: 1, borderColor: "#eee" }}>
            <Text>Produto: {item.productName}</Text>
            <Text>Valor: R$ {item.amount.toFixed(2)}</Text>
            <Text>Data: {new Date(item.createdAt).toLocaleDateString()}</Text>
          </View>
        )}
      />
    </View>
  );
}