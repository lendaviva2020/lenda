import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";
import { useAuth } from "../hooks/useAuth";

export default function LoginScreen({ navigation }) {
  const { login, user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleLogin() {
    try {
      await login(email, password);
      navigation.replace("AdminTabs");
    } catch (e) {
      Alert.alert("Erro", (e as Error).message);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login Administrativo</Text>
      <TextInput
        placeholder="Email"
        style={styles.input}
        value={email}
        autoCapitalize="none"
        onChangeText={setEmail}
      />
      <TextInput
        placeholder="Senha"
        style={styles.input}
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Entrar" onPress={handleLogin} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 32 },
  title: { fontSize: 26, fontWeight: "bold", marginBottom: 36, textAlign: "center" },
  input: { borderWidth: 1, borderColor: "#ccc", marginBottom: 16, padding: 10, borderRadius: 8 },
});