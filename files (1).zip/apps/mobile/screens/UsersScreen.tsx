import React, { useEffect, useState } from "react";
import { View, Text, FlatList } from "react-native";

export default function UsersScreen() {
  const [users, setUsers] = useState<any[]>([]);
  useEffect(() => {
    fetch("https://api.seusite.com/users")
      .then(r => r.json())
      .then(setUsers);
  }, []);
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: "bold", marginBottom: 8 }}>Usuários</Text>
      <FlatList
        data={users}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={{ padding: 10, borderBottomWidth: 1, borderColor: "#eee" }}>
            <Text style={{ fontWeight: "bold" }}>{item.name} ({item.email})</Text>
            <Text>Status: {item.active ? "Ativo" : "Inativo"}</Text>
          </View>
        )}
      />
    </View>
  );
}