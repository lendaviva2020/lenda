import React, { useEffect, useState } from "react";
import { View, Text, Button, Alert } from "react-native";

export default function ProductDetailsScreen({ route, navigation }) {
  const { id } = route.params;
  const [product, setProduct] = useState<any>(null);

  useEffect(() => {
    fetch(`https://api.seusite.com/products/${id}`)
      .then(r => r.json())
      .then(setProduct);
  }, [id]);

  async function deleteProduct() {
    const ok = await fetch(`https://api.seusite.com/products/${id}`, { method: "DELETE" });
    if (ok) {
      Alert.alert("Produto deletado!");
      navigation.goBack();
    }
  }

  if (!product) return <Text>Carregando...</Text>;

  return (
    <View style={{ padding: 16 }}>
      <Text style={{ fontSize: 22, fontWeight: "bold" }}>{product.name}</Text>
      <Text>Preço: R$ {product.price}</Text>
      <Text>Categoria: {product.category}</Text>
      <Button title="Excluir Produto" color="red" onPress={deleteProduct} />
    </View>
  );
}