import React, { useEffect, useState } from "react";
import { View, Text } from "react-native";
// Use uma lib como 'victory-native' ou 'react-native-chart-kit' para gráficos reais
export default function ReportsScreen() {
  const [stats, setStats] = useState<any>({});
  useEffect(() => {
    fetch("https://api.seusite.com/reports/stats")
      .then(r => r.json())
      .then(setStats);
  }, []);
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: "bold", marginBottom: 8 }}>Relatórios</Text>
      <Text>Vendas no mês: {stats.monthSales}</Text>
      <Text>Receita total: R$ {stats.totalRevenue}</Text>
      {/* Adicione gráficos reais aqui */}
    </View>
  );
}