import React, { useEffect, useState } from "react";
import { View, Text, ScrollView, StyleSheet } from "react-native";
import { LineChart, BarChart } from "react-native-chart-kit";
import { Dimensions } from "react-native";

const screenWidth = Dimensions.get("window").width;

export default function FinanceDashboard() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetch("https://api.seusite.com/reports/finance")
      .then(r => r.json())
      .then(setData);
  }, []);

  if (!data) return <Text>Carregando...</Text>;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Dashboard Financeiro</Text>
      <Text style={styles.label}>Receita Total:</Text>
      <Text style={styles.value}>R$ {data.totalRevenue.toFixed(2)}</Text>

      <Text style={styles.label}>Vendas no Mês:</Text>
      <Text style={styles.value}>{data.monthSales}</Text>

      <Text style={styles.label}>Saldo em Conta:</Text>
      <Text style={styles.value}>R$ {data.balance.toFixed(2)}</Text>

      <Text style={styles.label}>Receita dos últimos 6 meses</Text>
      <LineChart
        data={{
          labels: data.lastMonths.map((m: any) => m.label),
          datasets: [{ data: data.lastMonths.map((m: any) => m.revenue) }]
        }}
        width={screenWidth - 32}
        height={220}
        yAxisLabel="R$ "
        chartConfig={{
          backgroundColor: "#fff",
          backgroundGradientFrom: "#fff",
          backgroundGradientTo: "#fff",
          decimalPlaces: 2,
          color: (opacity = 1) => `rgba(129, 64, 87, ${opacity})`,
          labelColor: () => "#444",
        }}
        style={styles.chart}
      />
      <Text style={styles.label}>Vendas por categoria</Text>
      <BarChart
        data={{
          labels: data.categories.map((c: any) => c.name),
          datasets: [{ data: data.categories.map((c: any) => c.sales) }]
        }}
        width={screenWidth - 32}
        height={220}
        yAxisLabel=""
        chartConfig={{
          backgroundColor: "#fff",
          backgroundGradientFrom: "#fff",
          backgroundGradientTo: "#fff",
          decimalPlaces: 0,
          color: (opacity = 1) => `rgba(129, 64, 87, ${opacity})`,
          labelColor: () => "#444",
        }}
        style={styles.chart}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 12 },
  label: { fontSize: 16, marginTop: 14, color: "#814057" },
  value: { fontSize: 18, fontWeight: "bold", marginBottom: 4 },
  chart: { marginVertical: 8, borderRadius: 12 }
});