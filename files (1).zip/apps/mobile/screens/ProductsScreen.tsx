import React, { useEffect, useState } from "react";
import { View, Text, FlatList, Button, TextInput, Alert } from "react-native";
import { useAuth } from "../hooks/useAuth";

export default function ProductsScreen() {
  const [products, setProducts] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const { user } = useAuth();

  useEffect(() => {
    fetch("https://api.seusite.com/products")
      .then(r => r.json())
      .then(setProducts);
  }, []);

  async function addProduct() {
    try {
      const res = await fetch("https://api.seusite.com/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, price: parseFloat(price) }),
      });
      if (res.ok) {
        const newProd = await res.json();
        setProducts(ps => [newProd, ...ps]);
        setName(""); setPrice("");
      } else {
        throw new Error("Erro ao adicionar produto");
      }
    } catch (e) {
      Alert.alert("Erro", (e as Error).message);
    }
  }

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: "bold", marginBottom: 8 }}>Produtos</Text>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <TextInput placeholder="Nome" value={name} onChangeText={setName} style={{ flex: 1, borderWidth: 1, borderRadius: 8, padding: 8 }} />
        <TextInput placeholder="Preço" value={price} onChangeText={setPrice} keyboardType="decimal-pad" style={{ width: 80, borderWidth: 1, borderRadius: 8, padding: 8 }} />
        <Button title="Adicionar" onPress={addProduct} />
      </View>
      <FlatList
        data={products}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={{ padding: 10, borderBottomWidth: 1, borderColor: "#eee" }}>
            <Text style={{ fontWeight: "bold" }}>{item.name}</Text>
            <Text>Preço: R$ {item.price.toFixed(2)}</Text>
          </View>
        )}
      />
    </View>
  );
}