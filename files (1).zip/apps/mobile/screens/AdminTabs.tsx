import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import ProductsScreen from "./ProductsScreen";
import SalesScreen from "./SalesScreen";
import ReportsScreen from "./ReportsScreen";
import GiftCardsScreen from "./GiftCardsScreen";
import FinanceDashboard from "./FinanceDashboard";
import AdminNotifications from "./AdminNotifications";
import UsersScreen from "./UsersScreen";

const Tab = createBottomTabNavigator();

export default function AdminTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Financeiro" component={FinanceDashboard} />
      <Tab.Screen name="Produtos" component={ProductsScreen} />
      <Tab.Screen name="Vendas" component={SalesScreen} />
      <Tab.Screen name="Relatórios" component={ReportsScreen} />
      <Tab.Screen name="Cartões-Presente" component={GiftCardsScreen} />
      <Tab.Screen name="Usuários" component={UsersScreen} />
      <Tab.Screen name="Notificações" component={AdminNotifications} />
    </Tab.Navigator>
  );
}