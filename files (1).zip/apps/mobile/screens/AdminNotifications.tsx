import React, { useEffect, useState } from "react";
import { View, Text, FlatList, StyleSheet } from "react-native";

export default function AdminNotifications() {
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    fetch("https://api.seusite.com/notifications?type=admin")
      .then(r => r.json())
      .then(setNotifications);
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Notificações do Admin</Text>
      <FlatList
        data={notifications}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.type}>{item.type}</Text>
            <Text style={styles.message}>{item.message}</Text>
            <Text style={styles.date}>{new Date(item.createdAt).toLocaleString()}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: "bold", marginBottom: 12 },
  card: { padding: 12, marginBottom: 10, backgroundColor: "#f9f3f6", borderRadius: 10 },
  type: { fontWeight: "bold", color: "#814057" },
  message: { fontSize: 16, marginTop: 4 },
  date: { fontSize: 12, color: "#888", marginTop: 4 },
});