import React, { useEffect, useState } from "react";
import { View, Text, ScrollView, StyleSheet } from "react-native";

export default function AdminDashboard() {
  const [financeData, setFinanceData] = useState<any>(null);

  useEffect(() => {
    fetch("https://api.seusite.com/reports/finance")
      .then(r => r.json())
      .then(setFinanceData);
  }, []);

  if (!financeData) return <Text style={{ textAlign: "center", marginTop: 40 }}>Carregando...</Text>;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Saldo Atual</Text>
      <View style={styles.balanceBox}>
        <Text style={styles.balanceLabel}>Contas Correntes:</Text>
        <Text style={styles.balanceValue}>
          R$ {financeData.currentAccounts?.toFixed(2) ?? "0,00"}
        </Text>
        <Text style={styles.balanceLabel}>Cartões:</Text>
        <Text style={styles.balanceValue}>
          R$ {financeData.cards?.toFixed(2) ?? "0,00"}
        </Text>
      </View>

      <Text style={styles.sectionTitle}>PLANEJAMENTO</Text>
      <View style={styles.planBarContainer}>
        <View style={styles.planBarBackground}>
          <View style={[styles.planBar, { width: `${Math.min(financeData.planejado * 100 / financeData.meta, 100)}%` }]} />
        </View>
        <Text style={{ fontSize: 13, marginTop: 4 }}>
          R$ {financeData.planejado} gastos de R$ {financeData.meta} planejados
        </Text>
      </View>

      <Text style={styles.sectionTitle}>RENDA E GASTOS</Text>
      <View style={styles.incomeExpenseRow}>
        <View style={styles.incomeBox}>
          <Text style={styles.incomeLabel}>Renda</Text>
          <Text style={styles.incomeValue}>R$ {financeData.income?.toFixed(2) ?? "0,00"}</Text>
        </View>
        <View style={styles.expenseBox}>
          <Text style={styles.expenseLabel}>Gastos</Text>
          <Text style={styles.expenseValue}>R$ {financeData.expenses?.toFixed(2) ?? "0,00"}</Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Resumo Semanal</Text>
      <View style={styles.summaryBox}>
        {financeData.weekSummary.map((item: any, i: number) => (
          <View key={i} style={styles.summaryRow}>
            <Text style={styles.summaryCat}>{item.category}</Text>
            <Text style={styles.summaryValue}>R$ {item.value}</Text>
          </View>
        ))}
      </View>

      <Text style={styles.sectionTitle}>Histórico de Transações</Text>
      <View style={styles.historyBox}>
        {financeData.transactions.slice(0, 8).map((tr: any, i: number) => (
          <View key={i} style={styles.transRow}>
            <Text style={styles.transDate}>{tr.date}</Text>
            <Text style={styles.transDesc}>{tr.description}</Text>
            <Text style={[styles.transValue, { color: tr.type === "income" ? "#2ca45c" : "#c03c53" }]}>
              {tr.type === "income" ? "+" : "-"}R$ {tr.amount.toFixed(2)}
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f8fafc" },
  header: { fontSize: 20, fontWeight: "bold", color: "#814057", marginBottom: 8 },
  balanceBox: { backgroundColor: "#fff", borderRadius: 12, padding: 10, marginBottom: 10, elevation: 2 },
  balanceLabel: { fontSize: 14, color: "#888" },
  balanceValue: { fontSize: 18, fontWeight: "bold", color: "#814057" },
  sectionTitle: { marginTop: 18, fontWeight: "bold", fontSize: 16, color: "#814057" },
  planBarContainer: { marginTop: 4, marginBottom: 6 },
  planBarBackground: { height: 12, backgroundColor: "#eee", borderRadius: 6, overflow: "hidden" },
  planBar: { height: 12, backgroundColor: "#814057", borderRadius: 6 },
  incomeExpenseRow: { flexDirection: "row", gap: 12, marginVertical: 8 },
  incomeBox: { backgroundColor: "#e6fff0", flex: 1, borderRadius: 10, padding: 10 },
  incomeLabel: { color: "#2ca45c", fontWeight: "bold" }, incomeValue: { fontSize: 17, color: "#2ca45c" },
  expenseBox: { backgroundColor: "#ffeef1", flex: 1, borderRadius: 10, padding: 10 },
  expenseLabel: { color: "#c03c53", fontWeight: "bold" }, expenseValue: { fontSize: 17, color: "#c03c53" },
  summaryBox: { backgroundColor: "#fff", borderRadius: 10, padding: 10, marginTop: 8, marginBottom: 8 },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 4 },
  summaryCat: { fontSize: 14, color: "#888" }, summaryValue: { fontWeight: "bold", color: "#222" },
  historyBox: { backgroundColor: "#fff", borderRadius: 10, padding: 10, marginTop: 8, marginBottom: 16 },
  transRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginVertical: 2 },
  transDate: { fontSize: 12, color: "#888", width: 65 },
  transDesc: { flex: 1, marginLeft: 8, fontSize: 14, color: "#444" },
  transValue: { fontWeight: "bold", fontSize: 14, marginLeft: 4 },
});