export type GiftCard = {
  id: string;
  code: string;
  value: number;
  used: boolean;
  usedBy?: string;
  expiresAt?: string;
  createdAt: string;
};