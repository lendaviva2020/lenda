export type Subscription = {
  id: string;
  userId: string;
  productId: string;
  interval: "monthly" | "weekly";
  nextChargeAt: string;
  active: boolean;
};