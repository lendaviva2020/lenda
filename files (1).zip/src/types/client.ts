export type Client = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  addresses: Address[];
  birthDate?: string;
  wishlist: string[];
  orders: string[];
  referrals: string[];
  createdAt: string;
};
export type Address = {
  label: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  country: string;
};