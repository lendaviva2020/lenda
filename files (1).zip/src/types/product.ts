export type Product = {
  id: string;
  vendorId: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  tags: string[];
  stock: number;
  isActive: boolean;
  commissionPercent?: number; // comissão do marketplace
  brand?: string;
  deliveryTime?: string;
  ratings?: number[]; // avaliações dos clientes
  createdAt: string;
  updatedAt?: string;
  approved?: boolean;
  blockedReason?: string;
};