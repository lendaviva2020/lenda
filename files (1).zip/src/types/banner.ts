export type Banner = {
  id: string;
  imageUrl: string;
  title: string;
  link?: string;
  startAt?: string;
  endAt?: string;
  active: boolean;
  createdAt: string;
  updatedAt?: string;
};