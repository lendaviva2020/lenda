export type Sale = {
  id: string;
  vendorId: string;
  productId: string;
  orderId: string;
  quantity: number;
  amount: number;
  paymentStatus: "paid" | "pending" | "refunded";
  commission: number;
  createdAt: string;
  buyerId: string;
  deliveryStatus: "processing" | "sent" | "delivered" | "returned";
  rated?: boolean;
};