export type StockEntry = {
  id: string;
  productId: string;
  location: string;
  quantity: number;
};