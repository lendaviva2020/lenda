export type Coupon = {
  id: string;
  code: string;
  discountPercent: number;
  minValue: number;
  validUntil: string;
  forNewClientsOnly?: boolean;
  useLimit?: number;
  usedBy?: string[];
  createdAt: string;
  updatedAt?: string;
};