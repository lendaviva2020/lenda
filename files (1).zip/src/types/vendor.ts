export type Vendor = {
  id: string;
  name: string;
  email: string;
  cnpj: string;
  phone?: string;
  address?: string;
  approved: boolean;
  logoUrl?: string;
  description?: string;
  categories: string[];
  products: string[]; // IDs dos produtos
  balance: number; // saldo disponível
  totalSales: number; // total vendido
  createdAt: string;
  updatedAt?: string;
  documents?: string[]; // URLs de documentos para aprovação
  ratings?: number[]; // avaliações dos clientes
};