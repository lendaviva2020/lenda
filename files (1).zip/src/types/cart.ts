export type Cart = {
  id: string;
  clientId: string;
  items: { productId: string; quantity: number }[];
  updatedAt: string;
  checkedOut: boolean;
};