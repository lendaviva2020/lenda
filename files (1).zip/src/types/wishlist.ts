export type Wishlist = {
  id: string;
  userId: string;
  productIds: string[];
  updatedAt: string;
};