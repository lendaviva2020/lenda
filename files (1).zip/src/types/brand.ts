export enum ClothesBrand {
  VIA_CORPUS = "Via Corpus",
  COLMEIA = "Colmeia",
  DONALLI = "Donalli",
  COURO_CAFE = "Couro Café",
  ZIG_FINA = "Zig Fina",
  REBUALF = "Rebualf",
  WJ = "WJ (Bolsas)",
  RAFFITY = "Raffity"
}