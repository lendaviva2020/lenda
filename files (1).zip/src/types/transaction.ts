export type Transaction = {
  id: string;
  userId: string;
  amount: number;
  method: "credit_card" | "pix" | "boleto";
  status: "pending" | "approved" | "refused";
  createdAt: string;
  splitDetails?: { recipient: string; value: number }[];
  couponUsed?: string;
};