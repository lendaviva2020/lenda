export type AuditLog = {
  id: string;
  userId: string;
  action: string;
  resource: string;
  resourceId?: string;
  timestamp: string;
  details?: any;
  ip?: string;
};