import type { NextApiRequest, NextApiResponse } from "next";
import axios from "axios";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { cepDestino, peso = 1 } = req.query;
  // Exemplo: SEDEX cálculo simples
  const params = new URLSearchParams({
    nCdEmpresa: "",
    sDsSenha: "",
    nCdServico: "04014", // SEDEX
    sCepOrigem: "01310930", // CEP de origem
    sCepDestino: cepDestino as string,
    nVlPeso: peso as string,
    nCdFormato: "1",
    nVlComprimento: "20",
    nVlAltura: "5",
    nVlLargura: "15",
    nVlDiametro: "0",
    sCdMaoPropria: "N",
    nVlValorDeclarado: "0",
    sCdAvisoRecebimento: "N",
    StrRetorno: "xml"
  });

  const url = `https://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx?${params}`;
  try {
    const { data } = await axios.get(url);
    res.status(200).send(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}