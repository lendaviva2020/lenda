// Exemplo de API route usando middlewares de segurança
import { apiLimiter, sanitizeInput, requireAdmin, blockBlacklistedIPs, logAudit } from "@/services/security";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await apiLimiter(req, res, () => {});
  blockBlacklistedIPs(req, res, () => {});
  // Exemplo: apenas admins podem acessar
  requireAdmin(req, res, async () => {
    // Sanitiza input
    const safeBody = sanitizeInput(req.body);
    // ...processa ação segura
    await logAudit({
      userId: req.user.id,
      action: "Ação Admin Segura",
      resource: "secureEndpoint"
    });
    res.status(200).json({ message: "Operação segura realizada!" });
  });
}