# Política de Privacidade

Sua privacidade é importante para a Beauty da Lu.  
Coletamos apenas os dados necessários para realizar suas compras, informá-lo sobre seu pedido e melhorar sua experiência na loja.

- **Coleta de dados:** Nome, e-mail, endereço, telefone, histórico de pedidos, preferências.
- **Uso dos dados:** Para processar pedidos, personalizar ofertas, enviar notificações e melhorar nossos serviços.
- **Compartilhamento:** Não vendemos nem compartilhamos seus dados com terceiros, exceto quando necessário para entrega, pagamento ou exigências legais.
- **Seus direitos:** Você pode solicitar a exclusão ou correção dos seus dados a qualquer momento.
- **Contato:** Em caso de dúvidas, escreva para contato@beautydalu.com.br

---

Ao usar nosso site, você concorda com esta política.