import { useCollection } from "@/hooks/useCollection";
import { Product } from "@/types/product";

// Para pegar produtos de um vendor e aprovar/bloquear
export function useVendorProducts(vendorId: string) {
  const { items, add, update, remove } = useCollection<Product>("products");
  const products = items.filter(p => p.vendorId === vendorId);

  async function approveProduct(id: string) {
    await update(id, { approved: true, blockedReason: null });
  }
  async function blockProduct(id: string, reason: string) {
    await update(id, { approved: false, blockedReason: reason });
  }
  return { products, add, update, remove, approveProduct, blockProduct };
}