import { useCollection } from "@/hooks/useCollection";
import { Sale } from "@/types/sale";

// Vendas filtradas por vendor, totalização de vendas e saldo
export function useVendorSales(vendorId: string) {
  const { items, add, update, remove } = useCollection<Sale>("sales");
  const sales = items.filter(s => s.vendorId === vendorId);
  const totalSales = sales.reduce((sum, s) => sum + s.amount, 0);
  const totalCommission = sales.reduce((sum, s) => sum + s.commission, 0);

  return { sales, add, update, remove, totalSales, totalCommission };
}