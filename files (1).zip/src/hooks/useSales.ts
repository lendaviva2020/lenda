import { useCollection } from "@/hooks/useCollection";
import { Sale } from "@/types/sale";

export function useSales() {
  return useCollection<Sale>("sales");
}