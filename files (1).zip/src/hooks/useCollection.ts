import { useEffect, useState } from "react";
import { getFirestore, collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc, query, orderBy } from "firebase/firestore";
import { app } from "@/services/firebase";

export function useCollection<T extends { id: string }>(collectionName: string, orderField: string = "createdAt") {
  const [items, setItems] = useState<T[]>([]);
  const db = getFirestore(app);

  useEffect(() => {
    const q = query(collection(db, collectionName), orderBy(orderField, "desc"));
    const unsub = onSnapshot(q, snap => {
      setItems(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as T)));
    });
    return unsub;
  }, [collectionName, orderField]);

  async function add(item: Omit<T, "id">) { await addDoc(collection(db, collectionName), item); }
  async function update(id: string, data: Partial<T>) { await updateDoc(doc(db, collectionName, id), data); }
  async function remove(id: string) { await deleteDoc(doc(db, collectionName, id)); }

  return { items, add, update, remove };
}