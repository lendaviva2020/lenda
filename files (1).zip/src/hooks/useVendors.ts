import { useCollection } from "@/hooks/useCollection";
import { Vendor } from "@/types/vendor";

// Hook para vendors com helpers de aprovação, alteração de saldo, etc.
export function useVendors() {
  const { items, add, update, remove } = useCollection<Vendor>("vendors");

  async function approveVendor(id: string) {
    await update(id, { approved: true });
  }
  async function rejectVendor(id: string, reason: string) {
    await update(id, { approved: false, blockedReason: reason });
  }
  async function updateBalance(id: string, value: number) {
    const vendor = items.find(v => v.id === id);
    if (vendor) {
      await update(id, { balance: vendor.balance + value });
    }
  }
  return { vendors: items, add, update, remove, approveVendor, rejectVendor, updateBalance };
}