import { useEffect, useState } from "react";
import { Transaction } from "@/types/transaction";
import { getFirestore, collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc } from "firebase/firestore";
import { app } from "@/firebase";

export function useTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const db = getFirestore(app);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "transactions"), snap => {
      setTransactions(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    });
    return unsub;
  }, []);

  async function addTransaction(data: Omit<Transaction, "id">) {
    await addDoc(collection(db, "transactions"), data);
  }

  async function updateTransaction(id: string, data: Partial<Transaction>) {
    await updateDoc(doc(db, "transactions", id), data);
  }

  async function removeTransaction(id: string) {
    await deleteDoc(doc(db, "transactions", id));
  }

  return { transactions, addTransaction, updateTransaction, removeTransaction };
}