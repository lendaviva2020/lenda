import { sendEmail, sendWhatsApp } from "./notifications";
import { Cart, Client } from "@/types";
export async function notifyAbandonedCarts(carts: Cart[], clients: Client[]) {
  const now = Date.now();
  for (const cart of carts) {
    if (!cart.checkedOut && now - new Date(cart.updatedAt).getTime() > 60 * 60 * 1000) {
      const client = clients.find(c => c.id === cart.clientId);
      if (client) {
        await sendEmail(client.email, "Finalize sua compra!", "Seu carrinho está esperando por você.");
        if (client.phone) await sendWhatsApp(client.phone, "Seu carrinho está te esperando na Beauty da Lu!");
      }
    }
  }
}