// Módulo central de segurança para #osucessodetodamulher
// Inclua este arquivo nos pontos críticos do backend ou middlewares do Next.js API

import { NextApiRequest, NextApiResponse } from "next";
import rateLimit from "express-rate-limit"; // ou use um pacote equivalente para Next.js API

// 1. Rate limiting (protege contra brute-force/DDOS simples)
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // máx de requisições por IP
  message: "Muitas requisições deste IP. Tente novamente em alguns minutos."
});

// 2. Sanitização de inputs (contra injeção)
export function sanitizeInput(input: any): any {
  if (typeof input === "string") {
    return input.replace(/[<>'"$;]/g, ""); // remove possíveis caracteres perigosos
  }
  if (typeof input === "object" && input !== null) {
    const sanitized: any = {};
    for (const key in input) {
      sanitized[key] = sanitizeInput(input[key]);
    }
    return sanitized;
  }
  return input;
}

// 3. Middleware de autenticação/admin
export function requireAdmin(req: NextApiRequest, res: NextApiResponse, next: Function) {
  if (!req.user || !req.user.isAdmin) {
    res.status(403).json({ error: "Acesso negado" });
    return;
  }
  next();
}

// 4. Auditoria de operações críticas
export async function logAudit(event: {
  userId: string;
  action: string;
  resource: string;
  resourceId?: string;
  details?: any;
}) {
  // Salve esse log em "auditLogs" no Firestore
  // await firestore.collection("auditLogs").add({ ...event, timestamp: new Date().toISOString() });
}

// 5. Função de verificação de IP suspeito (lista negra/bloqueio manual)
const blacklistedIPs = ["1.2.3.4", "5.6.7.8"];
export function blockBlacklistedIPs(req: NextApiRequest, res: NextApiResponse, next: Function) {
  const ip = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  if (ip && blacklistedIPs.includes(String(ip))) {
    res.status(403).json({ error: "IP bloqueado" });
    return;
  }
  next();
}

// 6. Proteção básica contra CSRF (para APIs REST)
export function checkCSRF(req: NextApiRequest, res: NextApiResponse, next: Function) {
  const csrfHeader = req.headers["x-csrf-token"];
  // Compare com o token armazenado na sessão do usuário
  if (!csrfHeader /* || csrfHeader !== sessionToken */) {
    res.status(403).json({ error: "CSRF inválido" });
    return;
  }
  next();
}

// 7. Detecção de comportamento suspeito (exemplo: várias tentativas de login)
export function detectSuspiciousBehavior(userId: string, action: string) {
  // Salve/fetch histórico de ações do userId
  // Se muitos erros ou tentativas, bloqueie temporariamente ou envie alerta ao admin
}

// 8. Reforço de autenticação (2FA para proprietários/admins)
export type TwoFASetup = {
  userId: string;
  secret: string; // chave do app autenticador
  enabled: boolean;
};