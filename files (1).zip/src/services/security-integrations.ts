/**
 * Integrações de segurança para #osucessodetodamulher
 * Exemplos de proteção via Cloudflare, WAF, Antifraude (ex: ClearSale, Konduto, etc.)
 * Implemente e ajuste conforme seu ambiente (Next.js, Vercel, backend próprio, etc.)
 */

// 1. Cloudflare Turnstile (anti-bot/CAPTCHA para formulários)
export async function verifyCloudflareTurnstile(token: string, remoteip?: string) {
  const secret = process.env.CLOUDFLARE_TURNSTILE_SECRET!;
  const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      secret,
      response: token,
      ...(remoteip ? { remoteip } : {})
    }).toString()
  });
  const data = await res.json();
  return data.success as boolean;
}

// 2. Cloudflare Headers (checar se requisição passou pelo proxy/WAF)
import { NextApiRequest, NextApiResponse } from "next";
export function checkCloudflareHeaders(req: NextApiRequest, res: NextApiResponse, next: Function) {
  const cfRay = req.headers["cf-ray"];
  const cfConnectingIp = req.headers["cf-connecting-ip"];
  if (!cfRay || !cfConnectingIp) {
    res.status(403).json({ error: "Acesso somente via Cloudflare permitido" });
    return;
  }
  next();
}

// 3. Web Application Firewall (WAF) - Exemplo de bloqueio manual (você pode automatizar via Cloudflare Rules)
export function blockUserAgent(req: NextApiRequest, res: NextApiResponse, next: Function) {
  const badAgents = ["sqlmap", "curl", "nikto", "acunetix", "bot"];
  const userAgent = String(req.headers["user-agent"] || "").toLowerCase();
  if (badAgents.some(agent => userAgent.includes(agent))) {
    res.status(403).json({ error: "User-Agent bloqueado pelo WAF" });
    return;
  }
  next();
}

// 4. Antifraude (ClearSale, Konduto, etc.) - Exemplo de integração ClearSale (pagamento)
export async function analyzeOrderWithClearSale(order: {
  id: string;
  total: number;
  payment: { method: string; cardNumber?: string };
  customer: { id: string; name: string; email: string; document: string };
  products: { id: string; name: string; price: number; qty: number }[];
}) {
  // Exemplo: integração fictícia, ajuste para a API real do provedor escolhido
  const url = "https://api.clearsale.com.br/v1/order/analyze";
  const auth = process.env.CLEARSALE_API_KEY!;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${auth}`
    },
    body: JSON.stringify(order)
  });
  const data = await res.json();
  // data.status: "APPROVED", "REJECTED", "MANUAL_REVIEW"
  return data.status;
}

// 5. Exemplo de uso (em API route)
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Proteção multi-camada
  checkCloudflareHeaders(req, res, () => {});
  blockUserAgent(req, res, () => {});

  // Exemplo: anti-bot em login/registro
  const turnstileToken = req.body.turnstileToken;
  if (!(await verifyCloudflareTurnstile(turnstileToken))) {
    res.status(400).json({ error: "Validação anti-bot falhou (Cloudflare Turnstile)" });
    return;
  }

  // Exemplo: Antifraude no checkout
  if (req.method === "POST" && req.body.type === "checkout") {
    const result = await analyzeOrderWithClearSale(req.body.order);
    if (result === "REJECTED") {
      res.status(403).json({ error: "Pedido recusado pelo antifraude" });
      return;
    }
    // Continue com o fluxo de pagamento...
  }

  res.status(200).json({ message: "Requisição segura e aprovada!" });
}