import { getFirestore, collection, addDoc } from "firebase/firestore";
import { app } from "@/firebase"; // configure seu firebase.ts

export async function saveTransaction(transaction: any) {
  const db = getFirestore(app);
  await addDoc(collection(db, "transactions"), transaction);
}