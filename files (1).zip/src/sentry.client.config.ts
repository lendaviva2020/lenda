import * as Sentry from "@sentry/nextjs";
Sentry.init({
  dsn: "SUA_DSN_SENTRY",
  tracesSampleRate: 1.0,
});