"use client";
import React, { useState } from "react";
import { useTransactions } from "@/hooks/useTransactions";
import TransactionTable from "@/components/admin/TransactionTable";
import TransactionForm from "@/components/admin/TransactionForm";
import { Transaction } from "@/types/transaction";

export default function TransactionsAdminPage() {
  const { transactions, addTransaction, updateTransaction, removeTransaction } = useTransactions();
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [showForm, setShowForm] = useState(false);

  function handleEdit(t: Transaction) {
    setEditing(t); setShowForm(true);
  }

  function handleDelete(id: string) {
    removeTransaction(id);
  }

  function handleSave(t: Omit<Transaction, "id">) {
    if (editing) {
      updateTransaction(editing.id, t);
    } else {
      addTransaction(t);
    }
    setEditing(null);
    setShowForm(false);
  }

  return (
    <div>
      <h2 style={{ color: "#814057" }}>Transações</h2>
      <button onClick={() => { setShowForm(true); setEditing(null); }} style={{
        background: "#814057", color: "#fff", border: "none", padding: "8px 24px", borderRadius: 8, fontWeight: 600, marginBottom: 20
      }}>+ Nova Transação</button>
      <TransactionTable transactions={transactions} onEdit={handleEdit} onDelete={handleDelete} />
      {showForm && (
        <div style={{
          position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
          background: "#81405788", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999
        }}>
          <TransactionForm initial={editing ?? undefined} onSave={handleSave} onCancel={() => setShowForm(false)} />
        </div>
      )}
    </div>
  );
}