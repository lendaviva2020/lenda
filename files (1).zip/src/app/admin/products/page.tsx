"use client";
import React, { useState } from "react";
import { useCollection } from "@/hooks/useCollection";
import ProductTable from "@/components/admin/ProductTable";
import ProductForm from "@/components/admin/ProductForm";
import { Product } from "@/types/product";
import { useNotify } from "@/components/GlobalNotification";

export default function AdminProductsPage() {
  const { items: products, add, update, remove } = useCollection<Product>("products");
  const [editing, setEditing] = useState<Product | null>(null);
  const [showForm, setShowForm] = useState(false);
  const { setMessage } = useNotify();

  function handleEdit(prod: Product) {
    setEditing(prod);
    setShowForm(true);
  }
  function handleDelete(id: string) {
    remove(id);
    setMessage("Produto excluído com sucesso!");
  }
  function handleSave(prod: Omit<Product, "id" | "createdAt">) {
    if (editing) {
      update(editing.id, prod);
      setMessage("Produto atualizado!");
    } else {
      add(prod);
      setMessage("Produto adicionado!");
    }
    setEditing(null);
    setShowForm(false);
  }

  return (
    <div>
      <h2 style={{ color: "#814057" }}>Produtos</h2>
      <button onClick={() => { setShowForm(true); setEditing(null); }} style={{ background: "#814057", color: "#fff", border: "none", padding: "8px 24px", borderRadius: 8, fontWeight: 600, marginBottom: 20 }}>+ Novo Produto</button>
      <ProductTable products={products} onEdit={handleEdit} onDelete={handleDelete} />
      {showForm && (
        <div style={{ position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh", background: "#81405788", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999 }}>
          <ProductForm initial={editing ?? undefined} onSave={handleSave} onCancel={() => setShowForm(false)} />
        </div>
      )}
    </div>
  );
}