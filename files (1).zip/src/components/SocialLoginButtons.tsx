import React from "react";
export default function SocialLoginButtons() {
  return (
    <div>
      <button style={btn} onClick={() => alert("Google login...")}>Entrar com Google</button>
      <button style={btn} onClick={() => alert("Facebook login...")}>Entrar com Facebook</button>
      <button style={btn} onClick={() => alert("Apple login...")}>Entrar com Apple</button>
    </div>
  );
}
const btn: React.CSSProperties = {
  background: "#F8E5DA", color: "#814057", border: "1.5px solid #814057",
  padding: "10px 20px", borderRadius: 8, fontWeight: 600, marginRight: 10, marginTop: 8, cursor: "pointer"
};