import React, { createContext, useContext, useState } from "react";

type NotifyContextType = { message: string; setMessage: (msg: string) => void; };
const NotifyContext = createContext<NotifyContextType>({ message: "", setMessage: () => {} });

export function useNotify() { return useContext(NotifyContext); }

export function NotifyProvider({ children }: { children: React.ReactNode }) {
  const [message, setMessage] = useState("");
  return (
    <NotifyContext.Provider value={{ message, setMessage }}>
      {children}
      {message && (
        <div style={{
          position: "fixed", top: 20, right: 20, background: "#D9B2C7",
          color: "#814057", borderRadius: 8, padding: "10px 24px", zIndex: 9999
        }}>{message}</div>
      )}
    </NotifyContext.Provider>
  );
}