import React, { useState } from "react";
import { useGiftCards } from "@/hooks/useGiftCards";
import { useAuth } from "@/hooks/useAuth";

export default function RedeemGiftCard() {
  const [code, setCode] = useState("");
  const { items: giftCards, update } = useGiftCards();
  const { user } = useAuth();

  function handleRedeem() {
    const gc = giftCards.find(g => g.code === code && !g.used);
    if (gc && user) {
      update(gc.id, { used: true, usedBy: user.id });
      alert(`Cartão de R$${gc.value} resgatado!`);
    } else {
      alert("Cartão inválido ou já usado.");
    }
  }
  return (
    <div>
      <input value={code} onChange={e => setCode(e.target.value)} placeholder="Código do cartão-presente" />
      <button onClick={handleRedeem}>Resgatar</button>
    </div>
  );
}