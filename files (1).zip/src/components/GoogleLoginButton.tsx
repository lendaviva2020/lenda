import React from "react";
import { auth, googleProvider } from "@/firebase";
import { signInWithPopup } from "firebase/auth";

export default function GoogleLoginButton() {
  function handleLogin() {
    signInWithPopup(auth, googleProvider)
      .then(result => alert(`Bem-vindo, ${result.user.displayName}!`))
      .catch(e => alert("Erro ao logar: " + e.message));
  }
  return (
    <button onClick={handleLogin} style={{
      background: "#fff",
      color: "#814057",
      border: "1.5px solid #814057",
      borderRadius: 8,
      fontWeight: 600,
      padding: "10px 24px",
      cursor: "pointer"
    }}>
      Entrar com Google
    </button>
  );
}