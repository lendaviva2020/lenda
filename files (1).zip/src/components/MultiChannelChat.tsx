import { useEffect } from "react";

export default function MultiChannelChat() {
  useEffect(() => {
    // WhatsApp widget
    const wpp = document.createElement("script");
    wpp.src = "https://static.whatshelp.io/widget.js";
    wpp.async = true;
    wpp.onload = () => {
      // @ts-ignore
      window.WhWidgetSendButton && window.WhWidgetSendButton.init({
        whatsapp: "+5599999999999",
        facebook: "yourfacebookpage",
        call_to_action: "Fale Conosco",
        position: "right",
      });
    };
    document.body.appendChild(wpp);

    // Messenger chat plugin
    const fb = document.createElement("div");
    fb.id = "fb-root";
    document.body.appendChild(fb);
    const chat = document.createElement("div");
    chat.id = "fb-customer-chat";
    chat.className = "fb-customerchat";
    chat.setAttribute("page_id", "YOUR_PAGE_ID");
    chat.setAttribute("attribution", "biz_inbox");
    document.body.appendChild(chat);

    const fbScript = document.createElement("script");
    fbScript.innerHTML = `
      window.fbAsyncInit = function() {
        FB.init({ xfbml: true, version: 'v19.0' });
      };
      (function(d, s, id) {
        if (d.getElementById(id)) {return;}
        var js = d.createElement(s); js.id = id;
        js.src = "https://connect.facebook.net/pt_BR/sdk/xfbml.customerchat.js";
        d.body.appendChild(js);
      }(document, 'script', 'facebook-jssdk'));
    `;
    document.body.appendChild(fbScript);

    // Tawk.to
    const tawk = document.createElement("script");
    tawk.async = true;
    tawk.src = "https://embed.tawk.to/SEU_ID/default";
    tawk.charset = "UTF-8";
    tawk.setAttribute("crossorigin", "*");
    document.body.appendChild(tawk);

    return () => {
      document.body.removeChild(wpp);
      document.body.removeChild(fb);
      document.body.removeChild(chat);
      document.body.removeChild(fbScript);
      document.body.removeChild(tawk);
    };
  }, []);
  return null;
}