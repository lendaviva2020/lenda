import React from "react";
import { auth } from "@/firebase";
import { FacebookAuthProvider, signInWithPopup } from "firebase/auth";
export default function FacebookLoginButton() {
  function handleLogin() {
    const provider = new FacebookAuthProvider();
    signInWithPopup(auth, provider)
      .then(result => alert(`Bem-vindo, ${result.user.displayName}!`))
      .catch(e => alert("Erro ao logar: " + e.message));
  }
  return (
    <button onClick={handleLogin} style={{
      background: "#4267B2",
      color: "#fff",
      border: "none",
      borderRadius: 8,
      padding: "10px 22px",
      fontWeight: 600
    }}>
      Entrar com Facebook
    </button>
  );
}