import React from "react";
import { Product } from "@/types/product";

type Props = { currentProduct: Product, allProducts: Product[] };

export default function SimilarProducts({ currentProduct, allProducts }: Props) {
  // Simples: sugere produtos da mesma categoria
  const similar = allProducts
    .filter(p => p.category === currentProduct.category && p.id !== currentProduct.id)
    .slice(0, 4);

  if (similar.length === 0) return null;

  return (
    <div style={{ marginTop: 36 }}>
      <h3 style={{ color: "#814057" }}>Você pode gostar também:</h3>
      <div style={{ display: "flex", gap: 18 }}>
        {similar.map(prod => (
          <div key={prod.id} style={{ width: 120, textAlign: "center" }}>
            <img src={prod.imageUrl} alt={prod.name} style={{ width: 100, height: 100, objectFit: "cover", borderRadius: 6, marginBottom: 6 }} />
            <div style={{ color: "#814057", fontWeight: 600 }}>{prod.name}</div>
            <div style={{ color: "#6C2852" }}>R$ {prod.price.toFixed(2)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}