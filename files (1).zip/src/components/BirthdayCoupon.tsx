import React from "react";

export default function BirthdayCoupon({ userBirth }: { userBirth: string }) {
  // Supondo userBirth: "YYYY-MM-DD"
  const today = new Date();
  const birth = new Date(userBirth);
  const isBirthday = today.getMonth() === birth.getMonth() && today.getDate() === birth.getDate();

  return isBirthday ? (
    <div style={{
      background: "#D9B2C7",
      color: "#814057",
      padding: 18,
      borderRadius: 10,
      fontWeight: 600,
      margin: "24px 0"
    }}>
      🎉 Parabéns pelo seu aniversário! Use o cupom <b>ANIVERSARIO10</b> para ganhar <b>10% OFF</b>!
    </div>
  ) : null;
}