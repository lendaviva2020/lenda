import React from "react";

// Simula envio de notificação por WhatsApp
export default function WhatsAppNotifyButton({ text }: { text: string }) {
  const phone = "5599999999999";
  const url = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      style={{
        background: "#25D366",
        color: "#fff",
        padding: "8px 16px",
        borderRadius: 7,
        fontWeight: 600,
        textDecoration: "none"
      }}
    >
      Notificar via WhatsApp
    </a>
  );
}