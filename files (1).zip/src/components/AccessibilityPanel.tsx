import React, { useState } from "react";

export default function AccessibilityPanel() {
  const [fontSize, setFontSize] = useState(16);
  const [highContrast, setHighContrast] = useState(false);

  function apply() {
    document.body.style.fontSize = `${fontSize}px`;
    document.body.style.filter = highContrast ? "contrast(1.5)" : "none";
  }

  return (
    <div style={{ background: "#fff8", color: "#814057", borderRadius: 8, padding: 14, margin: "16px 0" }}>
      <b>Acessibilidade:</b>
      <div>
        <label style={{ marginRight: 10 }}>
          <input
            type="range"
            min={14}
            max={26}
            value={fontSize}
            onChange={e => setFontSize(Number(e.target.value))}
            onMouseUp={apply}
            onTouchEnd={apply}
          />
          Tamanho da fonte: {fontSize}px
        </label>
        <label>
          <input
            type="checkbox"
            checked={highContrast}
            onChange={e => { setHighContrast(e.target.checked); apply(); }}
          />
          Alto contraste
        </label>
      </div>
    </div>
  );
}