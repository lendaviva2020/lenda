import React from "react";
import { useSales } from "@/hooks/useSales";
import { Chart } from "react-chartjs-2";

export default function SalesChart() {
  const { items: sales } = useSales();
  // Agrupa vendas por mês
  const dataByMonth: { [month: string]: number } = {};
  sales.forEach(s => {
    const month = s.date.slice(0, 7);
    dataByMonth[month] = (dataByMonth[month] || 0) + s.amount;
  });
  const labels = Object.keys(dataByMonth).sort();
  const data = labels.map(m => dataByMonth[m]);
  return (
    <div>
      <h4>Vendas por mês</h4>
      <Chart
        type="bar"
        data={{
          labels,
          datasets: [{ label: "Total vendido", data, backgroundColor: "#814057" }]
        }}
      />
    </div>
  );
}