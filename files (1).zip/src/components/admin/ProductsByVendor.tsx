import React from "react";
import { useCollection } from "@/hooks/useCollection";
import { Product } from "@/types/product";
import { Vendor } from "@/types/vendor";

export default function ProductsByVendor({ vendorId }: { vendorId: string }) {
  const { items: products } = useCollection<Product>("products");
  const myProducts = products.filter(p => p.vendorId === vendorId);
  return (
    <ul>
      {myProducts.map(p => (
        <li key={p.id}>{p.name} (R$ {p.price.toFixed(2)})</li>
      ))}
    </ul>
  );
}