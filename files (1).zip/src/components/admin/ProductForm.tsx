import React, { useState } from "react";
import { Product } from "@/types/product";

type Props = {
  initial?: Product;
  onSave: (prod: Omit<Product, "id" | "createdAt">) => void;
  onCancel: () => void;
};

export default function ProductForm({ initial, onSave, onCancel }: Props) {
  const [name, setName] = useState(initial?.name || "");
  const [brand, setBrand] = useState(initial?.brand || "");
  const [description, setDescription] = useState(initial?.description || "");
  const [price, setPrice] = useState(initial?.price?.toString() || "");
  const [imageUrl, setImageUrl] = useState(initial?.imageUrl || "");
  const [category, setCategory] = useState(initial?.category || "");
  const [tags, setTags] = useState(initial?.tags?.join(", ") || "");
  const [stock, setStock] = useState(initial?.stock?.toString() || "0");
  const [cashbackPercent, setCashbackPercent] = useState(initial?.cashbackPercent?.toString() || "");
  const [isNew, setIsNew] = useState(initial?.isNew || false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSave({
      name,
      brand,
      description,
      price: parseFloat(price),
      imageUrl,
      category,
      tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
      availableSizes: initial?.availableSizes,
      stock: Number(stock),
      cashbackPercent: cashbackPercent ? Number(cashbackPercent) : undefined,
      isNew,
      createdAt: initial?.createdAt || new Date().toISOString(),
    });
  }

  return (
    <form onSubmit={handleSubmit} style={{ background: "#fff", borderRadius: 12, padding: 18, maxWidth: 360 }}>
      <label>Nome</label>
      <input value={name} onChange={e => setName(e.target.value)} required />
      <label>Marca</label>
      <input value={brand} onChange={e => setBrand(e.target.value)} required />
      <label>Categoria</label>
      <input value={category} onChange={e => setCategory(e.target.value)} required />
      <label>Descrição</label>
      <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} />
      <label>Preço</label>
      <input type="number" value={price} onChange={e => setPrice(e.target.value)} required min={0} />
      <label>URL da imagem</label>
      <input value={imageUrl} onChange={e => setImageUrl(e.target.value)} />
      <label>Tags (separar por vírgula)</label>
      <input value={tags} onChange={e => setTags(e.target.value)} />
      <label>Estoque</label>
      <input type="number" value={stock} onChange={e => setStock(e.target.value)} min={0} />
      <label>% Cashback</label>
      <input type="number" value={cashbackPercent} onChange={e => setCashbackPercent(e.target.value)} min={0} max={100} />
      <label>
        <input type="checkbox" checked={isNew} onChange={e => setIsNew(e.target.checked)} /> Produto novo/lançamento
      </label>
      <div style={{ display: "flex", gap: 12, marginTop: 18 }}>
        <button type="button" onClick={onCancel} style={{ background: "#fff", color: "#814057", border: "1.5px solid #814057", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" }}>Cancelar</button>
        <button type="submit" style={{ background: "#814057", color: "#fff", border: "none", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" }}>Salvar</button>
      </div>
    </form>
  );
}