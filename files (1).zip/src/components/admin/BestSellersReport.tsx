import React from "react";

type Product = { id: string; name: string; sold: number };

type Props = { products: Product[] };

export default function BestSellersReport({ products }: Props) {
  const sorted = [...products].sort((a, b) => b.sold - a.sold);
  return (
    <div>
      <h3 style={{ color: "#814057" }}>Mais Vendidos</h3>
      <ol>
        {sorted.map(p => (
          <li key={p.id} style={{ color: "#814057" }}>{p.name} ({p.sold} vendas)</li>
        ))}
      </ol>
      <h3 style={{ color: "#814057" }}>Menos Vendidos</h3>
      <ol>
        {[...sorted].reverse().slice(0, 5).map(p => (
          <li key={p.id} style={{ color: "#814057" }}>{p.name} ({p.sold} vendas)</li>
        ))}
      </ol>
    </div>
  );
}