import React from "react";
import { useVendors } from "@/hooks/useVendors";
import { Vendor } from "@/types/vendor";

export default function VendorApprovalPanel() {
  const { items: vendors, update } = useVendors();

  return (
    <table>
      <thead>
        <tr><th>Nome</th><th>Email</th><th>CNPJ</th><th>Status</th><th>Ações</th></tr>
      </thead>
      <tbody>
        {vendors.map(v => (
          <tr key={v.id}>
            <td>{v.name}</td>
            <td>{v.email}</td>
            <td>{v.cnpj}</td>
            <td>{v.approved ? "Aprovado" : "Pendente"}</td>
            <td>
              {!v.approved && (
                <button onClick={() => update(v.id, { approved: true })}>Aprovar</button>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}