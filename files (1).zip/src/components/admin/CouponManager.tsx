import React, { useState } from "react";

type Coupon = {
  id: string;
  code: string;
  discountPercent: number;
  minValue: number;
  newClientsOnly: boolean;
  category?: string;
};

export default function CouponManager() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [input, setInput] = useState<Coupon>({
    id: "",
    code: "",
    discountPercent: 10,
    minValue: 0,
    newClientsOnly: false,
    category: ""
  });

  function handleAdd() {
    setCoupons(prev => [...prev, { ...input, id: Date.now().toString() }]);
    setInput({ id: "", code: "", discountPercent: 10, minValue: 0, newClientsOnly: false, category: "" });
  }

  return (
    <div>
      <h3 style={{ color: "#814057" }}>Gestão de Cupons</h3>
      <input placeholder="Código" value={input.code} onChange={e => setInput(i => ({ ...i, code: e.target.value }))} />
      <input type="number" placeholder="% Desconto" value={input.discountPercent} onChange={e => setInput(i => ({ ...i, discountPercent: Number(e.target.value) }))} />
      <input type="number" placeholder="Valor mínimo" value={input.minValue} onChange={e => setInput(i => ({ ...i, minValue: Number(e.target.value) }))} />
      <label>
        <input type="checkbox" checked={input.newClientsOnly} onChange={e => setInput(i => ({ ...i, newClientsOnly: e.target.checked }))} /> Só para novos clientes
      </label>
      <input placeholder="Categoria (opcional)" value={input.category} onChange={e => setInput(i => ({ ...i, category: e.target.value }))} />
      <button onClick={handleAdd} style={btnAdd}>Adicionar</button>
      <ul>
        {coupons.map(c => (
          <li key={c.id} style={{ margin: "12px 0", color: "#814057" }}>
            {c.code} - {c.discountPercent}% OFF {c.category && `(Categoria: ${c.category})`} {c.newClientsOnly && " (Novos clientes)"}
          </li>
        ))}
      </ul>
    </div>
  );
}
const btnAdd: React.CSSProperties = { background: "#814057", color: "#fff", border: "none", margin: "0 8px", borderRadius: 6, padding: "5px 14px" };