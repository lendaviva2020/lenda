import React, { useState } from "react";
import { Coupon } from "@/types/coupon";

type Props = {
  initial?: Coupon;
  onSave: (c: Omit<Coupon, "id" | "usedBy">) => void;
  onCancel: () => void;
};

export default function CouponForm({ initial, onSave, onCancel }: Props) {
  const [code, setCode] = useState(initial?.code || "");
  const [discountPercent, setDiscountPercent] = useState(initial?.discountPercent?.toString() || "10");
  const [minValue, setMinValue] = useState(initial?.minValue?.toString() || "0");
  const [validUntil, setValidUntil] = useState(initial?.validUntil || "");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSave({
      code,
      discountPercent: Number(discountPercent),
      minValue: Number(minValue),
      validUntil,
    });
  }
  return (
    <form onSubmit={handleSubmit}>
      <label>Código</label>
      <input value={code} onChange={e => setCode(e.target.value)} required />
      <label>% Desconto</label>
      <input type="number" value={discountPercent} onChange={e => setDiscountPercent(e.target.value)} required min={1} />
      <label>Valor mínimo</label>
      <input type="number" value={minValue} onChange={e => setMinValue(e.target.value)} required min={0} />
      <label>Válido até</label>
      <input type="date" value={validUntil} onChange={e => setValidUntil(e.target.value)} />
      <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
        <button type="button" onClick={onCancel} style={btnCancel}>Cancelar</button>
        <button type="submit" style={btnSave}>Salvar</button>
      </div>
    </form>
  );
}
const btnCancel = { background: "#fff", color: "#814057", border: "1.5px solid #814057", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" } as const;
const btnSave = { background: "#814057", color: "#fff", border: "none", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" } as const;