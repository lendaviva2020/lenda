// Setup de autenticação 2FA para admin/proprietário
import React, { useState } from "react";
export default function TwoFactorSetup({ userId }: { userId: string }) {
  const [enabled, setEnabled] = useState(false);
  // Implemente integração com serviço de 2FA (ex: speakeasy, google authenticator)
  return (
    <div>
      <h4>Autenticação em dois fatores (2FA)</h4>
      <p>
        {enabled
          ? "2FA ativado! Guarde seu código de backup em local seguro."
          : "Ative 2FA para maior segurança no acesso ao painel admin."}
      </p>
      <button onClick={() => setEnabled(true)} disabled={enabled}>
        Ativar 2FA
      </button>
    </div>
  );
}