import React from "react";

type Client = {
  id: string;
  name: string;
  totalOrders: number;
  totalSpent: number;
  favoriteCategory: string;
};

type Props = { clients: Client[] };

export default function ClientDashboard({ clients }: Props) {
  return (
    <div>
      <h3 style={{ color: "#814057" }}>Painel de Clientes</h3>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#F8E5DA" }}>
            <th>Nome</th><th>Pedidos</th><th>Valor total</th><th>Preferência</th>
          </tr>
        </thead>
        <tbody>
          {clients.map(c => (
            <tr key={c.id} style={{ borderBottom: "1px solid #eee", color: "#814057" }}>
              <td>{c.name}</td>
              <td>{c.totalOrders}</td>
              <td>R$ {c.totalSpent.toFixed(2)}</td>
              <td>{c.favoriteCategory}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}