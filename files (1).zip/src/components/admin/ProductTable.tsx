import React from "react";
import { Product } from "@/types/product";

type Props = {
  products: Product[];
  onEdit: (prod: Product) => void;
  onDelete: (id: string) => void;
};

export default function ProductTable({ products, onEdit, onDelete }: Props) {
  return (
    <table style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr style={{ background: "#F8E5DA" }}>
          <th>Nome</th>
          <th>Marca</th>
          <th>Estoque</th>
          <th>Preço</th>
          <th>Cashback</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
        {products.map(p => (
          <tr key={p.id}>
            <td>{p.name}</td>
            <td>{p.brand}</td>
            <td>{p.stock}</td>
            <td>R$ {p.price.toFixed(2)}</td>
            <td>{p.cashbackPercent ? `${p.cashbackPercent}%` : "-"}</td>
            <td>
              <button onClick={() => onEdit(p)} style={{ background: "#D9B2C7", color: "#6C2852", border: "none", borderRadius: 6, padding: "4px 12px", marginRight: 6, fontWeight: 600, cursor: "pointer" }}>Editar</button>
              <button onClick={() => onDelete(p.id)} style={{ background: "#fff", color: "#814057", border: "1.5px solid #814057", borderRadius: 6, padding: "4px 12px", fontWeight: 600, cursor: "pointer" }}>Excluir</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}