import React from "react";
import { Transaction } from "@/types/transaction";
type Props = {
  transactions: Transaction[];
  onEdit: (t: Transaction) => void;
  onDelete: (id: string) => void;
};
export default function TransactionTable({ transactions, onEdit, onDelete }: Props) {
  return (
    <table style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr style={{ background: "#F8E5DA" }}>
          <th>ID</th><th>Usuário</th><th>Valor</th><th>Método</th>
          <th>Status</th><th>Data</th><th>Ações</th>
        </tr>
      </thead>
      <tbody>
        {transactions.map(t => (
          <tr key={t.id}>
            <td>{t.id}</td><td>{t.userId}</td>
            <td>R$ {t.amount.toFixed(2)}</td>
            <td>{t.method}</td><td>{t.status}</td>
            <td>{new Date(t.createdAt).toLocaleString()}</td>
            <td>
              <button onClick={() => onEdit(t)} style={btn}>Editar</button>
              <button onClick={() => onDelete(t.id)} style={btnDel}>Excluir</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
const btn = { background: "#D9B2C7", color: "#6C2852", border: "none", borderRadius: 6, padding: "4px 12px", marginRight: 6, fontWeight: 600, cursor: "pointer" };
const btnDel = { ...btn, background: "#fff", color: "#814057", border: "1.5px solid #814057" };