import React from "react";
import { Product } from "@/types/product";

export default function ExportToCsvButton({ data }: { data: Product[] }) {
  function handleExport() {
    const csvHeader = "ID,Nome,Marca,Preço,Categoria\n";
    const csvRows = data.map(p =>
      [p.id, p.name, p.brand, p.price, p.category].join(",")
    );
    const csv = csvHeader + csvRows.join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "produtos.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <button style={btn} onClick={handleExport}>Exportar vendas (CSV)</button>
  );
}

const btn: React.CSSProperties = {
  background: "#814057",
  color: "#fff",
  border: "none",
  padding: "8px 18px",
  borderRadius: 8,
  fontWeight: 600,
  cursor: "pointer"
};