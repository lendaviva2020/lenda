import React, { useState } from "react";
import { useCollection } from "@/hooks/useCollection";
import { Vendor } from "@/types/vendor";
import { Product } from "@/types/product";
import { Sale } from "@/types/sale";

// Função utilitária para exportar CSV
function exportToCSV(data: any[], filename = "export.csv") {
  if (!data.length) return;
  const header = Object.keys(data[0]).join(",");
  const rows = data.map(obj =>
    Object.values(obj)
      .map(v => `"${String(v).replace(/"/g, '""')}"`)
      .join(",")
  );
  const csv = [header, ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  window.URL.revokeObjectURL(url);
}

export default function MarketplaceDashboard() {
  const { items: vendors, update: updateVendor } = useCollection<Vendor>("vendors");
  const { items: products, update: updateProduct } = useCollection<Product>("products");
  const { items: sales } = useCollection<Sale>("sales");

  const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);
  const [filterName, setFilterName] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "approved" | "pending">("all");
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [editingVendorId, setEditingVendorId] = useState<string | null>(null);

  // Filtros avançados de vendors
  const filteredVendors = vendors.filter(v =>
    (filterStatus === "all" || (filterStatus === "approved" ? v.approved : !v.approved)) &&
    v.name.toLowerCase().includes(filterName.toLowerCase())
  );

  const filteredProducts = selectedVendorId
    ? products.filter(p => p.vendorId === selectedVendorId)
    : [];

  const filteredSales = selectedVendorId
    ? sales.filter(s => s.vendorId === selectedVendorId)
    : [];

  // Edição inline de Vendor
  function VendorRow({ v }: { v: Vendor }) {
    const [name, setName] = useState(v.name);
    const [email, setEmail] = useState(v.email);
    const isEditing = editingVendorId === v.id;

    function save() {
      updateVendor(v.id, { name, email });
      setEditingVendorId(null);
    }

    return (
      <tr
        style={{
          background: isEditing ? "#FFE4FA" : "",
          fontWeight: selectedVendorId === v.id ? "bold" : "normal",
          color: v.approved ? "#814057" : "#aaa",
          cursor: "pointer"
        }}
        onClick={() => setSelectedVendorId(v.id)}
      >
        <td>
          {isEditing ? (
            <input value={name} onChange={e => setName(e.target.value)} />
          ) : (
            name
          )}
        </td>
        <td>
          {isEditing ? (
            <input value={email} onChange={e => setEmail(e.target.value)} />
          ) : (
            email
          )}
        </td>
        <td>{v.cnpj}</td>
        <td>{v.approved ? "✅" : "❌"}</td>
        <td>
          {isEditing ? (
            <>
              <button onClick={save}>Salvar</button>
              <button onClick={() => setEditingVendorId(null)}>Cancelar</button>
            </>
          ) : (
            <>
              <button onClick={e => { e.stopPropagation(); setEditingVendorId(v.id); }}>Editar</button>
              {!v.approved && (
                <button onClick={e => { e.stopPropagation(); updateVendor(v.id, { approved: true }); }}>Aprovar</button>
              )}
            </>
          )}
        </td>
      </tr>
    );
  }

  // Edição inline de Produto
  function ProductRow({ p }: { p: Product }) {
    const isEditing = editingProductId === p.id;
    const [name, setName] = useState(p.name);
    const [price, setPrice] = useState(p.price.toString());
    function save() {
      updateProduct(p.id, { name, price: parseFloat(price) });
      setEditingProductId(null);
    }
    return (
      <tr style={{ background: isEditing ? "#F8E5DA" : "" }}>
        <td>{p.id}</td>
        <td>
          {isEditing ? (
            <input value={name} onChange={e => setName(e.target.value)} />
          ) : (
            name
          )}
        </td>
        <td>
          {isEditing ? (
            <input type="number" value={price} onChange={e => setPrice(e.target.value)} />
          ) : (
            `R$ ${p.price.toFixed(2)}`
          )}
        </td>
        <td>{p.stock}</td>
        <td>
          {isEditing ? (
            <>
              <button onClick={save}>Salvar</button>
              <button onClick={() => setEditingProductId(null)}>Cancelar</button>
            </>
          ) : (
            <button onClick={() => setEditingProductId(p.id)}>Editar</button>
          )}
        </td>
      </tr>
    );
  }

  // Exportação CSV (products, vendors, sales do vendor selecionado)
  function handleExport(type: "vendors" | "products" | "sales") {
    if (type === "vendors") exportToCSV(filteredVendors, "vendors.csv");
    if (type === "products") exportToCSV(filteredProducts, "products.csv");
    if (type === "sales") exportToCSV(filteredSales, "sales.csv");
  }

  return (
    <div>
      <h2>Marketplace: Lojistas, Produtos e Vendas</h2>

      {/* Filtros avançados */}
      <div style={{ display: "flex", gap: 16, marginBottom: 16 }}>
        <input
          placeholder="Filtrar por nome do lojista"
          value={filterName}
          onChange={e => setFilterName(e.target.value)}
        />
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value as any)}>
          <option value="all">Todos</option>
          <option value="approved">Aprovados</option>
          <option value="pending">Pendentes</option>
        </select>
        <button onClick={() => handleExport("vendors")}>Exportar Lojistas CSV</button>
        {selectedVendorId && (
          <>
            <button onClick={() => handleExport("products")}>Exportar Produtos CSV</button>
            <button onClick={() => handleExport("sales")}>Exportar Vendas CSV</button>
          </>
        )}
      </div>

      <div style={{ display: "flex", gap: 40 }}>
        {/* Lista de Vendors */}
        <div>
          <h3>Lojistas</h3>
          <table>
            <thead>
              <tr>
                <th>Nome</th><th>Email</th><th>CNPJ</th><th>Status</th><th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredVendors.map(v => (
                <VendorRow key={v.id} v={v} />
              ))}
            </tbody>
          </table>
        </div>

        {/* Produtos do Vendor selecionado */}
        <div>
          <h3>Produtos do Lojista</h3>
          {selectedVendorId ? (
            filteredProducts.length > 0 ? (
              <table>
                <thead>
                  <tr>
                    <th>ID</th><th>Nome</th><th>Preço</th><th>Estoque</th><th>Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map(p => (
                    <ProductRow key={p.id} p={p} />
                  ))}
                </tbody>
              </table>
            ) : (
              <p>Nenhum produto cadastrado.</p>
            )
          ) : (
            <p>Selecione um lojista para ver seus produtos.</p>
          )}
        </div>

        {/* Vendas do Vendor selecionado */}
        <div>
          <h3>Vendas do Lojista</h3>
          {selectedVendorId ? (
            filteredSales.length > 0 ? (
              <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Produto</th>
                    <th>Valor</th>
                    <th>Qtd</th>
                    <th>Data</th>
                    <th>Status Pgto.</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSales.map(s => (
                    <tr key={s.id}>
                      <td>{s.id}</td>
                      <td>{products.find(p => p.id === s.productId)?.name || "Desconhecido"}</td>
                      <td>R$ {s.amount.toFixed(2)}</td>
                      <td>{s.quantity}</td>
                      <td>{new Date(s.createdAt).toLocaleDateString()}</td>
                      <td>{s.paymentStatus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p>Nenhuma venda registrada.</p>
            )
          ) : (
            <p>Selecione um lojista para ver suas vendas.</p>
          )}
        </div>
      </div>
    </div>
  );
}