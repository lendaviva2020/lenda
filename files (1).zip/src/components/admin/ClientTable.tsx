import React from "react";
import { Client } from "@/types/client";

type Props = {
  clients: Client[];
  onEdit: (c: Client) => void;
  onDelete: (id: string) => void;
};
export default function ClientTable({ clients, onEdit, onDelete }: Props) {
  return (
    <table style={{ width: "100%" }}>
      <thead>
        <tr><th>Nome</th><th>Email</th><th>Total gasto</th><th>Ações</th></tr>
      </thead>
      <tbody>
        {clients.map(c => (
          <tr key={c.id}>
            <td>{c.name}</td>
            <td>{c.email}</td>
            <td>R$ {c.totalSpent.toFixed(2)}</td>
            <td>
              <button onClick={() => onEdit(c)} style={btn}>Editar</button>
              <button onClick={() => onDelete(c.id)} style={btnDel}>Excluir</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
const btn = { background: "#D9B2C7", color: "#6C2852", border: "none", borderRadius: 6, padding: "4px 12px", marginRight: 6, fontWeight: 600, cursor: "pointer" };
const btnDel = { ...btn, background: "#fff", color: "#814057", border: "1.5px solid #814057" };