import React, { useState } from "react";
import { Transaction } from "@/types/transaction";
type Props = {
  initial?: Transaction;
  onSave: (t: Omit<Transaction, "id">) => void;
  onCancel: () => void;
};
export default function TransactionForm({ initial, onSave, onCancel }: Props) {
  const [userId, setUserId] = useState(initial?.userId || "");
  const [amount, setAmount] = useState(initial?.amount?.toString() || "");
  const [method, setMethod] = useState<Transaction["method"]>(initial?.method || "credit_card");
  const [status, setStatus] = useState<Transaction["status"]>(initial?.status || "pending");
  const [couponUsed, setCouponUsed] = useState(initial?.couponUsed || "");
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSave({
      userId,
      amount: parseFloat(amount),
      method,
      status,
      createdAt: initial?.createdAt || new Date().toISOString(),
      splitDetails: initial?.splitDetails,
      couponUsed: couponUsed || undefined,
    });
  }
  return (
    <form onSubmit={handleSubmit} style={{ background: "#fff", borderRadius: 12, padding: 24, boxShadow: "0 2px 24px #81405722", maxWidth: 400 }}>
      <label>Usuário</label>
      <input value={userId} onChange={e => setUserId(e.target.value)} required />
      <label>Valor</label>
      <input type="number" value={amount} onChange={e => setAmount(e.target.value)} required min={0} />
      <label>Método</label>
      <select value={method} onChange={e => setMethod(e.target.value as any)}>
        <option value="credit_card">Cartão</option>
        <option value="pix">Pix</option>
        <option value="boleto">Boleto</option>
      </select>
      <label>Status</label>
      <select value={status} onChange={e => setStatus(e.target.value as any)}>
        <option value="pending">Pendente</option>
        <option value="approved">Aprovado</option>
        <option value="refused">Recusado</option>
      </select>
      <label>Cupom usado</label>
      <input value={couponUsed} onChange={e => setCouponUsed(e.target.value)} />
      <div style={{ display: "flex", gap: 12, marginTop: 18 }}>
        <button type="button" onClick={onCancel} style={btnCancel}>Cancelar</button>
        <button type="submit" style={btnSave}>Salvar</button>
      </div>
    </form>
  );
}
const btnCancel = { background: "#fff", color: "#814057", border: "1.5px solid #814057", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" } as const;
const btnSave = { background: "#814057", color: "#fff", border: "none", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" } as const;