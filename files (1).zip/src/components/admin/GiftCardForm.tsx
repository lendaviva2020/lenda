import React, { useState } from "react";
import { GiftCard } from "@/types/giftcard";

type Props = {
  initial?: GiftCard;
  onSave: (d: Omit<GiftCard, "id" | "createdAt">) => void;
  onCancel: () => void;
};

export default function GiftCardForm({ initial, onSave, onCancel }: Props) {
  const [code, setCode] = useState(initial?.code || "");
  const [value, setValue] = useState(initial?.value?.toString() || "50");
  const [expiresAt, setExpiresAt] = useState(initial?.expiresAt || "");
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSave({ code, value: Number(value), used: initial?.used ?? false, expiresAt });
  }
  return (
    <form onSubmit={handleSubmit}>
      <label>Código</label>
      <input value={code} onChange={e => setCode(e.target.value)} required />
      <label>Valor</label>
      <input type="number" value={value} onChange={e => setValue(e.target.value)} min={1} required />
      <label>Expira em</label>
      <input type="date" value={expiresAt} onChange={e => setExpiresAt(e.target.value)} />
      <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
        <button type="button" onClick={onCancel}>Cancelar</button>
        <button type="submit">Salvar</button>
      </div>
    </form>
  );
}