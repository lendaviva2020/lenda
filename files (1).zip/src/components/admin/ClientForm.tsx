import React, { useState } from "react";
import { Client } from "@/types/client";

type Props = {
  initial?: Client;
  onSave: (c: Omit<Client, "id" | "createdAt" | "totalSpent">) => void;
  onCancel: () => void;
};

export default function ClientForm({ initial, onSave, onCancel }: Props) {
  const [name, setName] = useState(initial?.name || "");
  const [email, setEmail] = useState(initial?.email || "");
  const [birthDate, setBirthDate] = useState(initial?.birthDate || "");
  const [phone, setPhone] = useState(initial?.phone || "");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSave({
      name, email, phone, birthDate,
      addresses: initial?.addresses ?? [],
    });
  }
  return (
    <form onSubmit={handleSubmit} style={formStyle}>
      <label>Nome</label>
      <input value={name} onChange={e => setName(e.target.value)} required />
      <label>Email</label>
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
      <label>Telefone</label>
      <input value={phone} onChange={e => setPhone(e.target.value)} />
      <label>Data de nascimento</label>
      <input type="date" value={birthDate} onChange={e => setBirthDate(e.target.value)} />
      <div style={{ display: "flex", gap: 12, marginTop: 14 }}>
        <button type="button" onClick={onCancel} style={btnCancel}>Cancelar</button>
        <button type="submit" style={btnSave}>Salvar</button>
      </div>
    </form>
  );
}
const formStyle = { background: "#fff", borderRadius: 12, padding: 18, maxWidth: 340 } as const;
const btnCancel = { background: "#fff", color: "#814057", border: "1.5px solid #814057", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" } as const;
const btnSave = { background: "#814057", color: "#fff", border: "none", padding: "8px 24px", borderRadius: 8, fontWeight: 600, cursor: "pointer" } as const;