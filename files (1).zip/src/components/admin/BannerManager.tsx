import React, { useState } from "react";

type Banner = { id: string; imageUrl: string; title: string; active: boolean };

export default function BannerManager() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [input, setInput] = useState({ imageUrl: "", title: "" });

  function handleAdd() {
    setBanners(prev => [...prev, { ...input, id: Date.now().toString(), active: true }]);
    setInput({ imageUrl: "", title: "" });
  }
  function handleToggle(id: string) {
    setBanners(prev => prev.map(b => b.id === id ? { ...b, active: !b.active } : b));
  }

  return (
    <div>
      <h3 style={{ color: "#814057" }}>Gestão de Banners</h3>
      <input placeholder="URL da imagem" value={input.imageUrl} onChange={e => setInput(i => ({ ...i, imageUrl: e.target.value }))} />
      <input placeholder="Título" value={input.title} onChange={e => setInput(i => ({ ...i, title: e.target.value }))} />
      <button onClick={handleAdd} style={btnAdd}>Adicionar</button>
      <ul>
        {banners.map(b => (
          <li key={b.id} style={{ margin: "14px 0", color: b.active ? "#814057" : "#aaa" }}>
            <img src={b.imageUrl} alt={b.title} style={{ width: 90, height: 40, objectFit: "cover", borderRadius: 6, marginRight: 10 }} />
            {b.title}{" "}
            <button onClick={() => handleToggle(b.id)} style={btnToggle}>{b.active ? "Desativar" : "Ativar"}</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

const btnAdd: React.CSSProperties = { background: "#814057", color: "#fff", border: "none", margin: "0 8px", borderRadius: 6, padding: "5px 14px" };
const btnToggle: React.CSSProperties = { background: "#D9B2C7", color: "#6C2852", border: "none", borderRadius: 5, padding: "4px 10px" };