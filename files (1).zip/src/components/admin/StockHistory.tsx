import React, { useState } from "react";

type StockLog = { id: string; product: string; action: "add" | "remove"; qty: number; date: string };

export default function StockHistory() {
  const [logs, setLogs] = useState<StockLog[]>([]);

  function handleLog(product: string, action: "add" | "remove", qty: number) {
    setLogs(prev => [
      ...prev,
      { id: Date.now().toString(), product, action, qty, date: new Date().toLocaleString() }
    ]);
  }

  return (
    <div>
      <h3 style={{ color: "#814057" }}>Histórico de Estoque</h3>
      <button onClick={() => handleLog("Produto X", "add", 5)} style={btn}>+ 5 Produto X</button>
      <button onClick={() => handleLog("Produto Y", "remove", 2)} style={btn}>- 2 Produto Y</button>
      <ul>
        {logs.map(l => (
          <li key={l.id} style={{ margin: "8px 0", color: l.action === "add" ? "#25D366" : "#814057" }}>
            [{l.date}] {l.action === "add" ? "+" : "-"}{l.qty} {l.product}
          </li>
        ))}
      </ul>
    </div>
  );
}
const btn: React.CSSProperties = { background: "#D9B2C7", color: "#814057", border: "none", margin: "0 8px", borderRadius: 6, padding: "5px 14px" };