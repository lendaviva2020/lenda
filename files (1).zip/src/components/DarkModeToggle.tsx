import React, { useEffect, useState } from "react";

export default function DarkModeToggle() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    document.body.style.background = dark ? "#2D1125" : "#F8E5DA";
    document.body.style.color = dark ? "#fff" : "#814057";
  }, [dark]);

  return (
    <button
      onClick={() => setDark(d => !d)}
      style={{
        background: dark ? "#D9B2C7" : "#814057",
        color: dark ? "#814057" : "#fff",
        border: "none",
        borderRadius: 8,
        padding: "8px 18px",
        fontWeight: 600,
        margin: "12px 0",
        cursor: "pointer"
      }}
    >
      {dark ? "Modo Claro" : "Modo Escuro"}
    </button>
  );
}