import { useCollection } from "@/hooks/useCollection";
import { Review } from "@/types/product";
export default function ProductReviews({ productId }: { productId: string }) {
  const { items: reviews, add } = useCollection<Review>("reviews");
  const productReviews = reviews.filter(r => r.productId === productId);

  // Render estrelas, comentários, formulário para novo review
  return (
    <div>
      <h4>Avaliações</h4>
      {productReviews.map(r => (
        <div key={r.userId + r.createdAt}>
          <b>{r.rating}⭐</b> {r.comment}
        </div>
      ))}
      {/* Formulário para novo review */}
    </div>
  );
}