export default function Button({ children, ...props }) {
  return (
    <button {...props} aria-label={props["aria-label"]} style={{ ...props.style, outline: "2px solid #814057" }}>
      {children}
    </button>
  );
}