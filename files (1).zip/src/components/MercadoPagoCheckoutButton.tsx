import React from "react";
export default function MercadoPagoCheckoutButton({ preferenceId }: { preferenceId: string }) {
  React.useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://sdk.mercadopago.com/js/v2";
    script.async = true;
    script.onload = () => {
      // @ts-ignore
      const mp = new window.MercadoPago("SUA_PUBLIC_KEY", { locale: "pt-BR" });
      mp.checkout({
        preference: { id: preferenceId },
        render: { container: "#mp-checkout", label: "Pagar com Mercado Pago" }
      });
    };
    document.body.appendChild(script);
    return () => { document.body.removeChild(script); };
  }, [preferenceId]);
  return <div id="mp-checkout" />;
}