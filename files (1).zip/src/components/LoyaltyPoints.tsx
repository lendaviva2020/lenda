import React from "react";
export default function LoyaltyPoints({ userPoints }: { userPoints: number }) {
  const discount = Math.floor(userPoints / 100) * 10;
  return (
    <div style={{
      background: "#F8E5DA", padding: 16, borderRadius: 10, margin: "24px 0", color: "#814057"
    }}>
      <strong>Seus pontos: {userPoints}</strong><br />
      {discount > 0 ? (
        <span>Você pode trocar por <b>R$ {discount},00</b> de desconto!</span>
      ) : (
        <span>Junte mais pontos para ganhar descontos ou brindes.</span>
      )}
    </div>
  );
}