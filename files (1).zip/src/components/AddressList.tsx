import React, { useState } from "react";

export type Address = { id: string; label: string; address: string };

export default function AddressList({ addresses, onSelect }: { addresses: Address[], onSelect: (id: string) => void }) {
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div>
      <h4>Meus Endereços</h4>
      <ul>
        {addresses.map(a => (
          <li key={a.id} style={{ marginBottom: 5, color: "#814057" }}>
            <input
              type="radio"
              checked={selected === a.id}
              onChange={() => { setSelected(a.id); onSelect(a.id); }}
            />{" "}
            <b>{a.label}</b>: {a.address}
          </li>
        ))}
      </ul>
      <button style={{ ...btn, marginTop: 12 }}>Adicionar novo endereço</button>
    </div>
  );
}

const btn: React.CSSProperties = {
  background: "#814057",
  color: "#fff",
  border: "none",
  padding: "6px 15px",
  borderRadius: 8,
  fontWeight: 600,
  cursor: "pointer"
};