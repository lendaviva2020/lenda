import React, { useState } from "react";
function calcFrete(cep: string): { price: number, days: number } {
  if (cep.length === 8) return { price: 19.9, days: 4 };
  return { price: 0, days: 0 };
}
export default function FreightSimulator() {
  const [cep, setCep] = useState("");
  const [result, setResult] = useState<{ price: number, days: number } | null>(null);
  function handleSimulate(e: React.FormEvent) {
    e.preventDefault(); setResult(calcFrete(cep));
  }
  return (
    <form onSubmit={handleSimulate} style={{ margin: "16px 0" }}>
      <label>Simular frete:</label>
      <input type="text" value={cep} onChange={e => setCep(e.target.value.replace(/\D/g, "").slice(0, 8))}
        placeholder="Digite seu CEP" style={{ margin: "0 10px", borderRadius: 6, border: "1px solid #814057", padding: 6 }} required />
      <button type="submit" style={{ borderRadius: 6, padding: "5px 18px", background: "#814057", color: "#fff", border: "none" }}>Calcular</button>
      {result && (
        <div style={{ marginTop: 10, color: "#814057" }}>
          Frete: <b>R$ {result.price}</b> &nbsp;|&nbsp; Entrega em até <b>{result.days} dias úteis</b>
        </div>
      )}
    </form>
  );
}