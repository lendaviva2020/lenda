import React, { useState } from "react";

export default function CorreiosFreteSimulator() {
  const [cep, setCep] = useState("");
  const [result, setResult] = useState<string | null>(null);

  async function simulate() {
    const res = await fetch(`/api/correios-frete?cepDestino=${cep}`);
    const xml = await res.text();
    // Exemplo simples: extrair preço do XML (na prática, parseie melhor!)
    const valor = xml.match(/<Valor>([\d,]+)<\/Valor>/)?.[1];
    const prazo = xml.match(/<PrazoEntrega>(\d+)<\/PrazoEntrega>/)?.[1];
    setResult(valor && prazo ? `Frete: R$ ${valor} - Entrega em ${prazo} dias úteis` : "Erro ao consultar");
  }

  return (
    <div>
      <input value={cep} onChange={e => setCep(e.target.value)} placeholder="Digite o CEP" />
      <button onClick={simulate}>Calcular Frete</button>
      {result && <div style={{ color: "#814057" }}>{result}</div>}
    </div>
  );
}