import React from "react";

type Status = "Pagamento aprovado" | "Em separação" | "Enviado" | "Entregue";
type Props = { status: Status };

const statusOrder: Status[] = [
  "Pagamento aprovado", "Em separação", "Enviado", "Entregue"
];

export default function OrderTracking({ status }: Props) {
  const currentIdx = statusOrder.indexOf(status);

  return (
    <div style={{ color: "#814057", margin: "22px 0" }}>
      <h4>Status do pedido:</h4>
      <div style={{ display: "flex", gap: 20 }}>
        {statusOrder.map((s, i) => (
          <div key={s} style={{
            fontWeight: i <= currentIdx ? 700 : 400,
            color: i <= currentIdx ? "#814057" : "#D9B2C7"
          }}>
            {s}
            {i < statusOrder.length - 1 && <span style={{ margin: "0 8px" }}>→</span>}
          </div>
        ))}
      </div>
    </div>
  );
}