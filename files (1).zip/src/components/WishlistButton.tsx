import { useNotify } from "@/components/GlobalNotification";
import { useCollection } from "@/hooks/useCollection";
import { Client } from "@/types/client";
export default function WishlistButton({ productId, userId }: { productId: string; userId: string }) {
  const { items: clients, update } = useCollection<Client>("clients");
  const { setMessage } = useNotify();
  const client = clients.find(c => c.id === userId);
  const inWishlist = client?.wishlist.includes(productId);

  async function toggleWishlist() {
    if (!client) return;
    let wishlist = inWishlist
      ? client.wishlist.filter(id => id !== productId)
      : [...client.wishlist, productId];
    await update(client.id, { wishlist });
    setMessage(inWishlist ? "Removido da wishlist" : "Adicionado à wishlist!");
  }

  return (
    <button onClick={toggleWishlist} aria-label="Adicionar à wishlist">
      {inWishlist ? "💖" : "🤍"}
    </button>
  );
}