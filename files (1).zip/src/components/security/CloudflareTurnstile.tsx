// Componente de CAPTCHA Cloudflare Turnstile para Next.js/React
import React, { useEffect } from "react";

declare global {
  interface Window { turnstile: any }
}

type Props = {
  siteKey: string;
  onToken: (token: string) => void;
};

export default function CloudflareTurnstile({ siteKey, onToken }: Props) {
  useEffect(() => {
    if (!window.turnstile) {
      const script = document.createElement("script");
      script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js";
      script.async = true;
      document.body.appendChild(script);
      script.onload = () => {
        // Render CAPTCHA quando script estiver carregado
        window.turnstile.render("#cf-turnstile", {
          sitekey: siteKey,
          callback: onToken
        });
      };
    } else {
      window.turnstile.render("#cf-turnstile", {
        sitekey: siteKey,
        callback: onToken
      });
    }
  }, [siteKey, onToken]);

  return <div id="cf-turnstile" />;
}