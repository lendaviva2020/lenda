// Exiba este componente no dashboard do admin e na página de checkout
export default function SecurityTips() {
  return (
    <div style={{ background: "#FFE4E1", borderRadius: 8, padding: 16, margin: "16px 0" }}>
      <h4>🔒 Dicas de Segurança</h4>
      <ul>
        <li>Sempre use senhas fortes e únicas.</li>
        <li>Ative a autenticação em dois fatores (2FA) no painel admin.</li>
        <li>Nunca compartilhe seus dados de acesso.</li>
        <li>Desconfie de ofertas e links suspeitos por e-mail ou WhatsApp.</li>
        <li>Se notar atividade incomum, entre em contato com o suporte imediatamente.</li>
      </ul>
    </div>
  );
}