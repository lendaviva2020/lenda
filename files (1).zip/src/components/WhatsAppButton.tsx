import React from "react";
export default function WhatsAppButton() {
  const phone = "5599999999999";
  const message = encodeURIComponent("Olá, tenho uma dúvida sobre a loja Beauty da Lu!");
  return (
    <a href={`https://wa.me/${phone}?text=${message}`} target="_blank" rel="noopener noreferrer"
      style={{ background: "#25D366", color: "#fff", padding: "12px 24px", borderRadius: 8, fontWeight: 600, textDecoration: "none", display: "inline-block" }}>
      Fale conosco no WhatsApp
    </a>
  );
}