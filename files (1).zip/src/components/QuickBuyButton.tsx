import React from "react";
import { useRouter } from "next/navigation";

type Props = { productId: string };

export default function QuickBuyButton({ productId }: Props) {
  const router = useRouter();
  function handleClick() { router.push(`/checkout?product=${productId}`); }
  return (
    <button onClick={handleClick} style={{
      background: "#814057", color: "#fff", border: "none", borderRadius: 8,
      padding: "10px 32px", fontWeight: 700, fontSize: 18, cursor: "pointer"
    }}>
      Comprar agora
    </button>
  );
}