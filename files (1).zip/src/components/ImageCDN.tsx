import Image from "next/image";

export default function ImageCDN({ publicId, alt }: { publicId: string, alt?: string }) {
  const cloudName = "SEU_CLOUDINARY";
  const url = `https://res.cloudinary.com/${cloudName}/image/upload/${publicId}.jpg`;
  return <Image src={url} alt={alt ?? ""} width={480} height={480} />;
}