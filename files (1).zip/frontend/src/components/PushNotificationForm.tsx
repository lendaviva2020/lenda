import React, { useState } from "react";
import axios from "axios";

export default function PushNotificationForm() {
  const [mode, setMode] = useState<"category" | "user">("category");
  const [category, setCategory] = useState("");
  const [userId, setUserId] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [data, setData] = useState("");
  const [result, setResult] = useState<string | null>(null);

  async function sendPush(e: React.FormEvent) {
    e.preventDefault();
    setResult(null);
    try {
      const notification = {
        title,
        body,
        data: data ? JSON.parse(data) : {},
      };
      let res;
      if (mode === "category") {
        res = await axios.post("/api/push/category", { category, notification });
      } else {
        res = await axios.post("/api/push/user", { userId, notification });
      }
      setResult(JSON.stringify(res.data));
    } catch (err: any) {
      setResult(err?.response?.data?.error || String(err));
    }
  }

  return (
    <form onSubmit={sendPush} style={{ background: "#f8fafc", padding: 24, borderRadius: 12, maxWidth: 400 }}>
      <h3>Disparar Notificação Push</h3>
      <div>
        <label>
          <input
            type="radio"
            checked={mode === "category"}
            onChange={() => setMode("category")}
          /> Por Categoria
        </label>
        <label style={{ marginLeft: 16 }}>
          <input
            type="radio"
            checked={mode === "user"}
            onChange={() => setMode("user")}
          /> Por Usuário
        </label>
      </div>
      {mode === "category" ? (
        <div>
          <label>Categoria do Admin</label>
          <input value={category} onChange={e => setCategory(e.target.value)} required style={{ width: "100%" }} />
        </div>
      ) : (
        <div>
          <label>ID do Admin</label>
          <input value={userId} onChange={e => setUserId(e.target.value)} required style={{ width: "100%" }} />
        </div>
      )}
      <div>
        <label>Título</label>
        <input value={title} onChange={e => setTitle(e.target.value)} required style={{ width: "100%" }} />
      </div>
      <div>
        <label>Mensagem</label>
        <input value={body} onChange={e => setBody(e.target.value)} required style={{ width: "100%" }} />
      </div>
      <div>
        <label>Data extra (JSON)</label>
        <input
          placeholder='{"screen":"Sales"}'
          value={data}
          onChange={e => setData(e.target.value)}
          style={{ width: "100%" }}
        />
      </div>
      <button type="submit" style={{ marginTop: 12 }}>Enviar Notificação</button>
      {result && (
        <div style={{ marginTop: 16, background: "#fffbe6", padding: 8, borderRadius: 6 }}>
          <b>Resposta:</b> <pre style={{ whiteSpace: "pre-wrap" }}>{result}</pre>
        </div>
      )}
    </form>
  );
}