import React from "react";
import PushNotificationForm from "../../components/PushNotificationForm";

export default function AdminPushPage() {
  return (
    <div style={{ maxWidth: 600, margin: "0 auto", paddingTop: 40 }}>
      <h2>Admin - Enviar Notificação Push</h2>
      <PushNotificationForm />
    </div>
  );
}