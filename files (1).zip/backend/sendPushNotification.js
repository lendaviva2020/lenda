const admin = require("firebase-admin");
const serviceAccount = require("./firebase-service-account.json");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

async function sendPushNotification(tokens, notification) {
  if (!tokens.length) return;
  const message = {
    notification: {
      title: notification.title,
      body: notification.body,
    },
    data: notification.data || {},
    tokens,
  };
  try {
    const response = await admin.messaging().sendMulticast(message);
    console.log("Push enviada:", response.successCount, "sucesso(s)");
    return response;
  } catch (err) {
    console.error("Erro ao enviar push:", err);
  }
}

module.exports = { sendPushNotification };