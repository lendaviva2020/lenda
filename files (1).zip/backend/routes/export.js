// Exportação CSV de produtos (Express + json2csv)
const express = require("express");
const router = express.Router();
const Product = require("../models/product");
const { Parser } = require("json2csv");

router.get("/products/csv", async (req, res) => {
  const products = await Product.find();
  const fields = ["_id", "name", "price", "category", "createdAt"];
  const parser = new Parser({ fields });
  const csv = parser.parse(products);
  res.header("Content-Type", "text/csv");
  res.attachment("produtos.csv");
  res.send(csv);
});

module.exports = router;