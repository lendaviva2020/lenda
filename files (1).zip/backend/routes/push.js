const express = require("express");
const router = express.Router();
const { getAdminPushTokensByCategory, getAdminPushTokensByUserId, savePushTokenForAdmin } = require("../models/admin");
const { sendPushNotification } = require("../sendPushNotification");

// Registrar token push
router.post("/admin/push-register", async (req, res) => {
  const { adminId, token } = req.body;
  if (!adminId || !token) return res.status(400).json({ error: "Parâmetros obrigatórios" });
  await savePushTokenForAdmin(adminId, token);
  res.json({ ok: true });
});

// Enviar push para admins de uma categoria
router.post("/push/category", async (req, res) => {
  const { category, notification } = req.body;
  if (!category || !notification) return res.status(400).json({ error: "Parâmetros obrigatórios" });
  const tokens = await getAdminPushTokensByCategory(category);
  if (!tokens.length) return res.status(200).json({ message: "Nenhum admin nessa categoria" });
  const response = await sendPushNotification(tokens, notification);
  res.json({ success: true, response });
});

// Enviar push para admin específico
router.post("/push/user", async (req, res) => {
  const { userId, notification } = req.body;
  if (!userId || !notification) return res.status(400).json({ error: "Parâmetros obrigatórios" });
  const tokens = await getAdminPushTokensByUserId(userId);
  if (!tokens.length) return res.status(200).json({ message: "Usuário sem token push registrado" });
  const response = await sendPushNotification(tokens, notification);
  res.json({ success: true, response });
});

module.exports = router;