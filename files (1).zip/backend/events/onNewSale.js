const { getAdminPushTokens } = require("../models/admin");
const { sendPushNotification } = require("../sendPushNotification");

async function notifyAdminsOnNewSale(sale) {
  const tokens = await getAdminPushTokens();
  await sendPushNotification(tokens, {
    title: "Nova venda!",
    body: `Pedido #${sale.id} de R$${sale.amount.toFixed(2)}.`,
    data: { screen: "Sales", saleId: sale.id }
  });
}

module.exports = notifyAdminsOnNewSale;