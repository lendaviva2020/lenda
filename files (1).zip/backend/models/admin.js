// Funções para buscar tokens por categoria ou userId (exemplo MongoDB)
const Admin = require("./db").Admin; // ajuste para seu ORM/ODM

async function getAdminPushTokensByCategory(category) {
  const admins = await Admin.find({ category, pushToken: { $exists: true, $ne: null } });
  return admins.map(a => a.pushToken);
}

async function getAdminPushTokensByUserId(userId) {
  const admin = await Admin.findOne({ _id: userId, pushToken: { $exists: true, $ne: null } });
  return admin && admin.pushToken ? [admin.pushToken] : [];
}

async function savePushTokenForAdmin(adminId, token) {
  await Admin.updateOne({ _id: adminId }, { pushToken: token });
}

module.exports = {
  getAdminPushTokensByCategory,
  getAdminPushTokensByUserId,
  savePushTokenForAdmin,
};