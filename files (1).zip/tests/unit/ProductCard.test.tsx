import { render, screen } from "@testing-library/react";
import ProductCard from "@/components/ProductCard";
test("exibe nome do produto", () => {
  render(<ProductCard name="Batom" price={29} />);
  expect(screen.getByText("Batom")).toBeInTheDocument();
});