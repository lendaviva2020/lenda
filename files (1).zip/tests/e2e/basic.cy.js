describe("Home page", () => {
  it("abre e mostra título", () => {
    cy.visit("/");
    cy.contains("Beauty da Lu");
  });
});