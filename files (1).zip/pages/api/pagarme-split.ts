import type { NextApiRequest, NextApiResponse } from "next";
import axios from "axios";
const PAGARME_API_KEY = "SUA_API_KEY";
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();
  const { amount, card_hash, recipients } = req.body;
  try {
    const response = await axios.post(
      "https://api.pagar.me/1/transactions",
      {
        api_key: PAGARME_API_KEY,
        amount,
        card_hash,
        split_rules: recipients.map(r => ({
          recipient_id: r.recipient_id,
          percentage: r.percentage,
          liable: true,
          charge_processing_fee: true
        }))
      }
    );
    res.status(200).json(response.data);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}