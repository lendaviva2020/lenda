import axios from "axios";
import type { NextApiRequest, NextApiResponse } from "next";

const BLING_API_KEY = "SUA_CHAVE";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { nome, email } = req.body;
  try {
    const xml = `
      <clientes>
        <cliente>
          <nome>${nome}</nome>
          <email>${email}</email>
        </cliente>
      </clientes>
    `;
    const { data } = await axios.post(
      `https://bling.com.br/Api/v2/cliente/json/`,
      null,
      {
        params: { apikey: BLING_API_KEY, xml },
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
      }
    );
    res.status(200).json(data);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}